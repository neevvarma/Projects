import SwiftUI

@main
struct KandaAppApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    @StateObject private var storeKitManager = StoreKitManager.shared
    @StateObject private var userData = UserData()
    
    var body: some Scene {
        WindowGroup {
            SplashScreen()
                .environmentObject(storeKitManager)
                .environmentObject(userData)
        }
    }
}
