import SwiftUI

struct MultimodalChatView: View {
    @EnvironmentObject var userData: UserData
    @EnvironmentObject var storeKitManager: StoreKitManager
    @StateObject private var chatService = ChatService()
    @State private var scoreText: String = ""
    @State private var analysisText: String = ""
    @State private var isLoading = false
    @State private var selectedImages: [UIImage]
    @State private var showingImagePicker = false
    @State private var analysisGenerated = false
    @State private var showingPaywall = false
    
    init(images: [UIImage]) {
        _selectedImages = State(initialValue: images)
    }
    
    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                Text("Your Fitness Analysis")
                    .font(.custom("ProximaNova-Bold", size: 30))
                    .foregroundColor(.white)
                
                if !analysisGenerated {
                    if !selectedImages.isEmpty {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack {
                                ForEach(selectedImages.indices, id: \.self) { index in
                                    Image(uiImage: selectedImages[index])
                                        .resizable()
                                        .scaledToFit()
                                        .frame(height: 100)
                                        .cornerRadius(10)
                                }
                            }
                        }
                    }
                    
                    Button(action: {
                        generateAnalysis()
                    }) {
                        Text("Generate Analysis")
                            .font(.custom("ProximaNova-Bold", size: 18))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity)
                            .frame(height: 50)
                            .background(Color.white)
                            .cornerRadius(10)
                    }
                    .buttonStyle(PlainButtonStyle())
                }
                
                if isLoading {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        .scaleEffect(1.5)
                } else if analysisGenerated {
                    if storeKitManager.subscriptionTier == .none {
                        // Show score and upgrade prompt for non-subscribers
                        VStack(spacing: 20) {
                            if !scoreText.isEmpty {
                                Text("Current Fitness Level: \(scoreText)")
                                    .font(.custom("ProximaNova-Bold", size: 40))
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.black.opacity(0.2))
                                    .cornerRadius(15)
                            }
                            
                            Text("Get your detailed analysis and personalized plan")
                                .font(.headline)
                                .foregroundColor(.white)
                                .multilineTextAlignment(.center)
                            
                            Button(action: {
                                showingPaywall = true
                            }) {
                                Text("Unlock Full Analysis")
                                    .font(.custom("ProximaNova-Bold", size: 18))
                                    .foregroundColor(.black)
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 50)
                                    .background(Color.white)
                                    .cornerRadius(10)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    } else {
                        // Show full analysis for subscribers
                        VStack(spacing: 20) {
                            if !scoreText.isEmpty {
                                Text("Current Fitness Level: \(scoreText)")
                                    .font(.custom("ProximaNova-Bold", size: 40))
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.black.opacity(0.2))
                                    .cornerRadius(15)
                            }
                            
                            ScrollView(showsIndicators: true) {
                                Text(LocalizedStringKey(analysisText))
                                    .font(.custom("ProximaNova-Light", size: 16))
                                    .foregroundColor(.white)
                                    .lineSpacing(8)
                                    .multilineTextAlignment(.leading)
                                    .padding(.horizontal)
                            }
                        }
                    }
                }
            }
            .padding()
        }
        .navigationBarTitle("Fitness Analysis", displayMode: .inline)
        .navigationBarColor(backgroundColor: UIColor(Color.black), titleColor: UIColor(Color.white))
        .sheet(isPresented: $showingPaywall, onDismiss: {
            // Reset if the user completed a purchase
            if storeKitManager.subscriptionTier != .none {
                resetAnalysis()
            }
        }) {
            PaywallView()
        }
    }
    
    private func resetAnalysis() {
        scoreText = ""
        analysisText = ""
        analysisGenerated = false
        isLoading = false
        showingPaywall = false
    }
    
    private func generateAnalysis() {
        isLoading = true
        analysisGenerated = true
        
        Task {
            // Always generate the score first
            await fetchResponse(for: generateScore())
            
            // Only generate full analysis for subscribers
            if storeKitManager.subscriptionTier != .none {
                if storeKitManager.canPerformScan() {
                    await fetchResponse(for: generatePrompt())
                    saveAnalysis()
                    storeKitManager.decrementScanCount()
                } else {
                    showingPaywall = true
                }
            }
            
            isLoading = false
        }
    }
    
    private func generatePrompt() -> String {
        return """
        You are a personal trainer analyzing the current physical condition of a user based on the image provided. This image is of the user themselves, not a goal or ideal body type. Provide a detailed fitness analysis and plan, focusing on the following areas:
        
        1. Current State:  Give the estimated body fat range of this individual. Emphasize any visible muscle imbalances. Be specific on what muscles have an imbalance and estimate how big the imbalance is in inches. This measurement should be the difference in size/length of the imbalance. If size can't be measured in terms of length, measure it as a ratio or proportion with another relevant muscle group. In addition, mention what the ideal ratios/lengths are for each muscle. Analyze specific muscle groups: pectorals, serratus anterior, latissimus dorsi, biceps, triceps, quadriceps, hamstrings, and sternocleidomastoid muscles. Estimate measurements for key areas (e.g., hips, biceps, thighs) if possible.

        2. Potential Negative Consequences: Explain potential health risks if muscle imbalances or weaknesses are not addressed. Include relevant issues like hormonal imbalances, bone health, injury risks, and potential psychological impacts.

        3. Workout Plan: Provide a 4-day split routine tailored to the user's needs:
           Day 1: Push (Chest and Triceps)
           Day 2: Pull (Back and Biceps)
           Day 3: Legs
           Day 4: Shoulders and Abs
           For each day, list 4-6 exercises with rep ranges (e.g., 6-14x3).

        4. Diet Recommendations: Suggest 2-3 key dietary changes to support their fitness goals. Explain how these changes will help address any identified issues.

        5. Expected Outcomes: Briefly describe what improvements the user can expect by following this plan. Emphasize balanced muscle development and overall health improvements.

        Format your response using clear headings and proper indentation for readability. Do not use asterisks or hyphens for bullet points. Use newlines to separate sections and items within lists.

        User details:
        Age: \(userData.age)
        Height: \(userData.heightFeet) ft \(userData.heightInches) in
        Weight: \(userData.weight) lbs
        Physical Activity Level: \(userData.physicalActivity)
        Region Temperature: \(userData.regionTemperature)
        Occupation: \(userData.occupation)
        Analysis Focus: \(userData.analysisChoice)

        Remember, the goal is to help the user improve their fitness from their current state, not to achieve an unrealistic ideal.
        """
    }
    
    private func generateScore() -> String {
        return """
        You are assessing the current fitness level of a user based on the image provided and the user details. The image shows the user's current physical state, not a goal or ideal body type. Assign a fitness score from 1 to 100 that reflects their current condition and potential for improvement. Respond with only the number followed by "/100". For example: "65/100". Always give a numerical score in the analysis, even if the images are not of high quality.

        Guidelines for scoring:
        1-20: Beginner level, significant room for improvement
        21-40: Early stages of fitness journey, showing some progress
        41-60: Intermediate level, good overall fitness with clear areas to improve
        61-80: Advanced level, very good fitness with specific areas to refine
        81-100: Elite level, excellent condition with focus on maintaining and slight improvements

        Consider factors such as apparent muscle tone, body composition, and alignment with the provided user details. Provide only the numerical score (1-100) followed by "/100" without any additional explanation.
        """
    }
    
    private func formatAnalysis(_ text: String) -> String {
        var formattedText = text
        formattedText = formattedText.replacingOccurrences(of: "\\*", with: "", options: .regularExpression)
        
        let sectionTitles = ["Current State:", "Potential Negative Consequences:", "Workout Plan:", "Diet Recommendations:", "Expected Outcomes:"]
        for title in sectionTitles {
            formattedText = formattedText.replacingOccurrences(of: title, with: "\n\n\(title)\n")
        }
        
        let dayPattern = try! NSRegularExpression(pattern: "Day \\d+:")
        formattedText = dayPattern.stringByReplacingMatches(in: formattedText, options: [], range: NSRange(formattedText.startIndex..., in: formattedText), withTemplate: "\n$0\n")
        
        let lines = formattedText.components(separatedBy: .newlines)
        formattedText = lines.enumerated().map { (index, line) -> String in
            if line.contains("x3") || line.contains("reps") {
                return "        \(line.trimmingCharacters(in: .whitespaces))"
            }
            return line
        }.joined(separator: "\n")
        
        return formattedText.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    private func fetchResponse(for prompt: String) async {
        let imageData = selectedImages.map { $0.jpegData(compressionQuality: 0.1) ?? Data() }
        await chatService.sendMessage(message: prompt, imageData: imageData)
        
        guard let lastMessage = chatService.messages.last else { return }
        if prompt == generateScore() {
            scoreText = lastMessage.message
        } else {
            analysisText = formatAnalysis(lastMessage.message)
        }
    }
    
    private func saveAnalysis() {
        let newAnalysis = SavedAnalysis(date: Date(), score: scoreText, analysis: analysisText)
        userData.saveAnalysis(newAnalysis)
    }
}

struct MultimodalChatView_Previews: PreviewProvider {
    static var previews: some View {
        MultimodalChatView(images: [])
            .environmentObject(UserData())
            .environmentObject(StoreKitManager.shared)
    }
}
