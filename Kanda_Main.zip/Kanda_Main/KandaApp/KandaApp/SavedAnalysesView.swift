import SwiftUI

struct SavedAnalysesView: View {
    @EnvironmentObject var userData: UserData
    @EnvironmentObject var storeKitManager: StoreKitManager
    @State private var showingDeleteConfirmation = false
    @State private var analysisToDelete: SavedAnalysis?
    @State private var showingPaywall = false
    
    var body: some View {
        NavigationView {
            Group {
                if storeKitManager.subscriptionTier != .none {
                    ScrollView {
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 100))], spacing: 20) {
                            ForEach(userData.savedAnalyses) { analysis in
                                NavigationLink(destination: AnalysisDetailView(analysis: analysis)) {
                                    FolderView(name: analysis.folderName)
                                }
                                .contextMenu {
                                    Button(action: {
                                        analysisToDelete = analysis
                                        showingDeleteConfirmation = true
                                    }) {
                                        Label("Delete", systemImage: "trash")
                                    }
                                }
                            }
                        }
                        .padding()
                    }
                } else {
                    VStack {
                        Text("Subscribe to access saved analyses")
                            .font(.headline)
                            .padding()
                        Button("Subscribe Now") {
                            showingPaywall = true
                        }
                        .buttonStyle(FuturisticButtonStyle())
                    }
                }
            }
            .navigationTitle("Saved Analyses")
        }
        .alert(isPresented: $showingDeleteConfirmation) {
            Alert(
                title: Text("Delete Analysis"),
                message: Text("Are you sure you want to delete this analysis?"),
                primaryButton: .destructive(Text("Delete")) {
                    if let analysis = analysisToDelete,
                       let index = userData.savedAnalyses.firstIndex(where: { $0.id == analysis.id }) {
                        userData.deleteAnalysis(at: IndexSet(integer: index))
                    }
                },
                secondaryButton: .cancel()
            )
        }
        .sheet(isPresented: $showingPaywall) {
            PaywallView()
        }
    }
}

struct FolderView: View {
    let name: String
    
    var body: some View {
        VStack {
            Image(systemName: "folder.fill")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 60, height: 60)
                .foregroundColor(.blue)
            Text(name)
                .font(.caption)
                .lineLimit(2)
                .multilineTextAlignment(.center)
        }
        .frame(width: 100, height: 100)
    }
}

struct SavedAnalysesView_Previews: PreviewProvider {
    static var previews: some View {
        SavedAnalysesView()
            .environmentObject(UserData())
            .environmentObject(StoreKitManager.shared)
    }
}
