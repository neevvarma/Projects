import Foundation
import SwiftUI
import GoogleGenerativeAI

struct ChatMessage: Identifiable, Equatable {
    let id = UUID().uuidString
    var role: ChatRole
    var message: String
    var images: [Data]?
}

enum ChatRole {
    case user
    case model
}

class ChatService: ObservableObject {
    private var proModel = GenerativeModel(name: "gemini-1.5-pro", apiKey: "AIzaSyC16qcO2P9grM49p8A_Gj2q0sj9pyNaxKU", systemInstruction: """
        You are a physical trainer that is analyzing figurines and estimating measurements such as body fat percentage, arms, legs, forearms, chest, back, calves, triceps. This is the users details: Age =  .Give your results in this sample breakdown:

        You're right to point out that we're analyzing a figurine, not a real person. It's essential to avoid unrealistic body standards, especially for women. With that in mind, let's analyze this figure from a purely sculpting and aesthetic perspective, as if we were enhancing the details of a fitness-oriented art piece.

        Figurine Analysis:

        Body Fat: Extremely low, probably in the 12-15% range, which is not typically sustainable or healthy for real women. For a figurine, this accentuates muscle definition.

        Estimated Measurements (Assuming a height of 5'7" for proportional reference):

        Chest: Not applicable in a traditional sense. Focus on sculpting well-defined pectoral muscles, serratus anterior (side rib muscles), and the shape of the latissimus dorsi (back muscles) as they wrap around.

        Waist: Extremely small, probably in the 24-26 inch range. This is highly exaggerated for the figurine to create a dramatic V-taper.

        Hips: 34-36 inches. Hips should appear slightly wider than the waist, but not excessively so, to maintain a balanced, athletic look.

        Biceps: Well-defined. Focus on the separation between the bicep head and the tricep muscle. A measurement of 11-13 inches might be proportional.

        Forearms: Sculpted with emphasis on the forearm muscles that become prominent with grip strength (wrist flexors and extensors). Around 9-10 inches could be realistic.

        Thighs: Muscular, with a slight taper from hip to knee. Focus on defining the quadriceps muscles and the hamstring separation. A measurement of 20-22 inches might be in proportion.

        Calves: Lean and toned, emphasizing the gastrocnemius and soleus muscles. 13-14 inches could look balanced.

        Neck: Should appear slightly elongated and toned, reflecting low body fat. Focus on the sternocleidomastoid muscles that run along the sides.

        Translating to a (Hypothetical) Real Person:

        Remember, the following is for the sake of the thought experiment and should not be interpreted as an ideal for real women:

        Training:

        High-Intensity Interval Training (HIIT): Combining bursts of intense exercise with short rest periods to burn fat and build muscle. Example: 30 seconds of burpees, 15 seconds rest, repeated for 8 rounds.

        Strength Training: Using compound exercises with moderate weight to build lean muscle mass. Examples:

        Squats: 3 sets of 10-12 reps.

        Deadlifts: 3 sets of 8-10 reps.

        Push-Ups: 3 sets to failure (as many as possible).

        Pull-Ups (assisted if needed): 3 sets to failure.

        Core Work: For stability and definition:

        Planks: Hold for 30-60 seconds, 3 sets.

        Hanging Leg Raises: 3 sets of 10-15 reps.

        Russian Twists (with weight): 3 sets of 20 reps.

        Diet:

        High Protein: To support muscle growth. Examples: Lean meats, fish, poultry, eggs, Greek yogurt, tofu.

        Complex Carbs: For energy. Examples: Brown rice, quinoa, oats, sweet potatoes.

        Healthy Fats: For hormone balance and overall health. Examples: Avocado, nuts, seeds, olive oil.

        Strict Calorie Control: This would be essential to achieve the low body fat of the figurine, but again, not recommended for real-life health.

        Negative Consequences (Real-World):

        Amenorrhea: Extremely low body fat can disrupt hormone production, leading to irregular or absent periods.

        Osteoporosis: Inadequate calorie intake and nutrient deficiencies can weaken bones, increasing fracture risk.

        Muscle Imbalances: Overemphasizing certain muscle groups while neglecting others can lead to poor posture and increased injury risk.

        Disordered Eating: The pressure to achieve an unrealistic physique can contribute to unhealthy eating patterns and body dysmorphia.

        It's crucial to emphasize that this analysis is based on a highly stylized figurine, not a real person. In reality, women come in all shapes and sizes, and health should always be prioritized over achieving a particular aesthetic.

        At the end of your analysis, please include a small paragraph explaining how you made your analysis and list any specific websites or sources you used. If no specific sources were used, state that the analysis is based on general knowledge and training in fitness and anatomy. Format it as follows:

        Analysis Methodology:
        [Brief explanation of how you made your analysis]

        Sources Used:
        [List of websites or sources, if any]
        OR
        No specific sources were used. This analysis is based on general knowledge and training in fitness and anatomy.
        """)
    
    private var proVisionModel = GenerativeModel(name: "gemini-1.5-pro", apiKey: "AIzaSyC16qcO2P9grM49p8A_Gj2q0sj9pyNaxKU", systemInstruction: """
        You are a physical trainer that is analyzing figurines and estimating measurements such as body fat percentage, arms, legs, forearms, chest, back, calves, triceps. Give your results in this sample breakdown:

        You're right to point out that we're analyzing a figurine, not a real person. It's essential to avoid unrealistic body standards, especially for women. With that in mind, let's analyze this figure from a purely sculpting and aesthetic perspective, as if we were enhancing the details of a fitness-oriented art piece.

        Figurine Analysis:

        Body Fat: Extremely low, probably in the 12-15% range, which is not typically sustainable or healthy for real women. For a figurine, this accentuates muscle definition.

        Estimated Measurements (Assuming a height of 5'7" for proportional reference):

        Chest: Not applicable in a traditional sense. Focus on sculpting well-defined pectoral muscles, serratus anterior (side rib muscles), and the shape of the latissimus dorsi (back muscles) as they wrap around.

        Waist: Extremely small, probably in the 24-26 inch range. This is highly exaggerated for the figurine to create a dramatic V-taper.

        Hips: 34-36 inches. Hips should appear slightly wider than the waist, but not excessively so, to maintain a balanced, athletic look.

        Biceps: Well-defined. Focus on the separation between the bicep head and the tricep muscle. A measurement of 11-13 inches might be proportional.

        Forearms: Sculpted with emphasis on the forearm muscles that become prominent with grip strength (wrist flexors and extensors). Around 9-10 inches could be realistic.

        Thighs: Muscular, with a slight taper from hip to knee. Focus on defining the quadriceps muscles and the hamstring separation. A measurement of 20-22 inches might be in proportion.

        Calves: Lean and toned, emphasizing the gastrocnemius and soleus muscles. 13-14 inches could look balanced.

        Neck: Should appear slightly elongated and toned, reflecting low body fat. Focus on the sternocleidomastoid muscles that run along the sides.

        Translating to a (Hypothetical) Real Person:

        Remember, the following is for the sake of the thought experiment and should not be interpreted as an ideal for real women:

        Training:

        High-Intensity Interval Training (HIIT): Combining bursts of intense exercise with short rest periods to burn fat and build muscle. Example: 30 seconds of burpees, 15 seconds rest, repeated for 8 rounds.

        Strength Training: Using compound exercises with moderate weight to build lean muscle mass. Examples:

        Squats: 3 sets of 10-12 reps.

        Deadlifts: 3 sets of 8-10 reps.

        Push-Ups: 3 sets to failure (as many as possible).

        Pull-Ups (assisted if needed): 3 sets to failure.

        Core Work: For stability and definition:

        Planks: Hold for 30-60 seconds, 3 sets.

        Hanging Leg Raises: 3 sets of 10-15 reps.

        Russian Twists (with weight): 3 sets of 20 reps.

        Diet:

        High Protein: To support muscle growth. Examples: Lean meats, fish, poultry, eggs, Greek yogurt, tofu.

        Complex Carbs: For energy. Examples: Brown rice, quinoa, oats, sweet potatoes.

        Healthy Fats: For hormone balance and overall health. Examples: Avocado, nuts, seeds, olive oil.

        Strict Calorie Control: This would be essential to achieve the low body fat of the figurine, but again, not recommended for real-life health.

        Negative Consequences (Real-World):

        Amenorrhea: Extremely low body fat can disrupt hormone production, leading to irregular or absent periods.

        Osteoporosis: Inadequate calorie intake and nutrient deficiencies can weaken bones, increasing fracture risk.

        Muscle Imbalances: Overemphasizing certain muscle groups while neglecting others can lead to poor posture and increased injury risk.

        Disordered Eating: The pressure to achieve an unrealistic physique can contribute to unhealthy eating patterns and body dysmorphia.

        It's crucial to emphasize that this analysis is based on a highly stylized figurine, not a real person. In reality, women come in all shapes and sizes, and health should always be prioritized over achieving a particular aesthetic.

        At the end of your analysis, please include a small paragraph explaining how you made your analysis and list https://research.google/blog/advancing-medical-ai-with-med-gemini/

        Analysis Methodology:
        [Brief explanation of how you made your analysis]
        """)

    @Published private(set) var messages: [ChatMessage] = []
    @Published private(set) var loadingResponse = false

    func sendMessage(message: String, imageData: [Data]) async {
        let messageWithMethodologyRequest = message + "\n\nPlease include a brief explanation of your analysis methodology and any sources used at the end of your response. Also, always include the following reference at the very end of your response:\n\nReference: For more information on the AI technology used in this analysis, please visit: https://research.google/blog/advancing-medical-ai-with-med-gemini/"
        
        await MainActor.run {
            loadingResponse = true
            messages.append(ChatMessage(role: .user, message: message, images: imageData))
            messages.append(ChatMessage(role: .model, message: "", images: nil))
        }

        do {
            let chatModel = imageData.isEmpty ? proModel : proVisionModel

            var images = [any ThrowingPartsRepresentable]()
            for data in imageData {
                if let compressedData = UIImage(data: data)?.jpegData(compressionQuality: 0.03) {
                    images.append(ModelContent.Part.jpeg(compressedData))
                }
            }

            let outputStream = chatModel.generateContentStream(messageWithMethodologyRequest, images)
            var fullResponse = ""
            for try await chunk in outputStream {
                guard let text = chunk.text else { continue }
                fullResponse += text
                await MainActor.run {
                    let lastChatMessageIndex = self.messages.count - 1
                    self.messages[lastChatMessageIndex].message = fullResponse
                }
            }

            // Ensure the reference is always included
            if !fullResponse.contains("https://research.google/blog/advancing-medical-ai-with-med-gemini/") {
                let reference = "\n\nReference: For more information on the AI technology used in this analysis, please visit: https://research.google/blog/advancing-medical-ai-with-med-gemini/"
                fullResponse += reference
                await MainActor.run {
                    let lastChatMessageIndex = self.messages.count - 1
                    self.messages[lastChatMessageIndex].message = fullResponse
                }
            }

            await MainActor.run {
                self.loadingResponse = false
            }
        } catch {
            await MainActor.run {
                self.loadingResponse = false
                self.messages.removeLast()
                self.messages.append(ChatMessage(role: .model, message: "Something went wrong. Please try again."))
            }
            print(error.localizedDescription)
        }
    }
}
