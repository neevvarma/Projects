import SwiftUI

struct HowToUseView: View {
    var body: some View {
        ScrollView{
            VStack(alignment: .leading, spacing: 20) {
                Text("How to Use the App")
                    .font(.custom("ProximaNova-Bold", size: 24))
                    .padding(.bottom, 10)
                
                ForEach(0..<4) { index in
                    HStack(alignment: .top, spacing: 10) {
                        Text("\(index + 1).")
                            .font(.custom("ProximaNova-Bold", size: 18))
                            .frame(width: 25, alignment: .leading)
                        
                        Text(getInstructionText(for: index))
                            .font(.custom("ProximaNova-Light", size: 18))
                    }
                }
                
                // Health Disclaimer
                VStack(alignment: .leading, spacing: 10) {
                    Text("Health Disclaimer")
                        .font(.custom("ProximaNova-Bold", size: 20))
                        .foregroundColor(.white)
                    
                    Text("Please seek a doctor's advice in addition to using this app and before making any medical decisions. The health analysis and insights provided by this app are for informational and educational purposes only. They are not intended to be a substitute for professional medical advice, diagnosis, or treatment.")
                        .font(.custom("ProximaNova-Light", size: 16))
                        .foregroundColor(.white)
                    
                    Text("Contact us: contact@kandaapp.com")
                        .font(.custom("ProximaNova-Light", size: 16))
                        .foregroundColor(.white)
                        .padding(.top, 5)
                }
                .padding()
                .background(Color.gray.opacity(0.2))
                .cornerRadius(10)
                
                // Move the banner closer to the text
                VStack {
                    Spacer(minLength: 0) // This will push the banner up as much as possible
                    
                    Text("We do not store or share your data")
                        .font(.custom("ProximaNova-Bold", size: 20))
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.black)
                        .cornerRadius(10)
                        .padding(.top, 10) // Adjust spacing from the text above
                    
                    Link(destination: URL(string:"https://app.termly.io/policy-viewer/policy.html?policyUUID=a7b86c0a-7cc4-4a3b-8f16-1e87634cafb4")!, label: {
                        Label("Privacy Policy", systemImage: "lock.fill")
                            .frame(width: 250, height: 40)
                            .background(Color.white)
                            .foregroundColor(.black)
                            .border(Color.black, width: 2) // Rectangular border
                    })
                    Link(destination: URL(string:"https://app.termly.io/policy-viewer/policy.html?policyUUID=ce7f3b8b-719e-438f-9c0a-8f655ef32c2a")!, label: {
                        Label("Terms and Conditions", systemImage: "lock.fill")
                            .frame(width: 250, height: 40)
                            .background(Color.white)
                            .foregroundColor(.black)
                            .border(Color.black, width: 2) // Rectangular border
                    })
                }
                .frame(maxWidth: .infinity) // Center the banner
            }
            .padding()
        }
        .background(Color.black.edgesIgnoringSafeArea(.all))
        .foregroundColor(.white)
    }
    
    private func getInstructionText(for index: Int) -> String {
        switch index {
        case 0:
            return "Take pictures in JPEG form by going to Settings > Camera > Formats and select 'Most Compatible'."
        case 1:
            return "Take a picture of your front side while flexing your arms then one with muscles relaxed. Repeat the process for your back side too."
        case 2:
            return "Wait for the analysis to run, it can take up to a minute, so please be patient."
        case 3:
            return "The chatbot can be used for many different tasks, such as creating customized meal plans, personalized workouts, and interpreting personal health information."
        default:
            return ""
        }
    }
}

#Preview {
    HowToUseView()
}
