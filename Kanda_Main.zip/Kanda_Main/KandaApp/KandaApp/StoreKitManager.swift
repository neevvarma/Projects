import StoreKit
import SwiftUI

@MainActor
class StoreKitManager: ObservableObject {
    static let shared = StoreKitManager()
    
    @Published var subscriptionTier: SubscriptionTier = .none
    @Published var messageCount: Int = 0
    @Published var scanCount: Int = 0
    @Published var storingEnabled: Bool = false
    
    enum SubscriptionTier: String {
        case none, basic, standard, premium
    }
    
    private let productIdentifiers = [
        "com.kandaapplication.subscription.basic",
        "com.kandaapplication.subscription.standard",
        "com.kandaapplication.subscription.premium"
    ]
    
    @Published private(set) var products: [Product] = []
    
    private init() {
        Task {
            await loadProducts()
            await updateSubscriptionStatus()
        }
    }
    
    func loadProducts() async {
        do {
            products = try await Product.products(for: productIdentifiers)
            print("StoreKitManager: Loaded \(products.count) products")
            for product in products {
                print("StoreKitManager: Product - ID: \(product.id), Title: \(product.displayName)")
            }
        } catch {
            print("StoreKitManager: Failed to load products: \(error)")
        }
    }
    
    func updateSubscriptionStatus() async {
        print("StoreKitManager: Updating subscription status")
        for await result in StoreKit.Transaction.currentEntitlements {
            if case .verified(let transaction) = result {
                handleVerifiedTransaction(transaction)
            }
        }
        print("StoreKitManager: Subscription status updated - Tier: \(subscriptionTier)")
    }
    
    private func handleVerifiedTransaction(_ transaction: StoreKit.Transaction) {
        print("StoreKitManager: Handling verified transaction for product ID: \(transaction.productID)")
        switch transaction.productID {
        case "com.kandaapplication.subscription.premium":
            subscriptionTier = .premium
            messageCount = Int.max
            scanCount = Int.max
            storingEnabled = true
        case "com.kandaapplication.subscription.standard":
            subscriptionTier = .standard
            messageCount = 15
            scanCount = 10
            storingEnabled = true
        case "com.kandaapplication.subscription.basic":
            subscriptionTier = .basic
            messageCount = 3
            scanCount = 1
            storingEnabled = false
        default:
            subscriptionTier = .none
            messageCount = 0
            scanCount = 0
            storingEnabled = false
        }
        print("StoreKitManager: Transaction handled - New tier: \(subscriptionTier)")
        print("StoreKitManager: Scan count set to: \(scanCount)")
    }
    
    func purchase(_ tier: SubscriptionTier) async throws {
        print("StoreKitManager: Attempting to purchase tier \(tier)")
        let productId = "com.kandaapplication.subscription.\(tier.rawValue)"
        print("StoreKitManager: Looking for product with ID: \(productId)")
        
        guard let product = products.first(where: { $0.id == productId }) else {
            print("StoreKitManager: Product not found for ID: \(productId)")
            print("StoreKitManager: Available products: \(products.map { $0.id }.joined(separator: ", "))")
            throw NSError(domain: "StoreKitManager", code: 0, userInfo: [NSLocalizedDescriptionKey: "Product not found"])
        }
        
        print("StoreKitManager: Found product: \(product.id), \(product.displayName)")
        let result = try await product.purchase()
        
        switch result {
        case .success(let verification):
            print("StoreKitManager: Purchase success, verifying transaction")
            if case .verified(let transaction) = verification {
                await transaction.finish()
                await updateSubscriptionStatus()
                print("StoreKitManager: Transaction verified and finished")
            }
        case .userCancelled:
            print("StoreKitManager: User cancelled the purchase")
            throw NSError(domain: "StoreKitManager", code: 1, userInfo: [NSLocalizedDescriptionKey: "Purchase cancelled"])
        case .pending:
            print("StoreKitManager: Purchase is pending")
            throw NSError(domain: "StoreKitManager", code: 2, userInfo: [NSLocalizedDescriptionKey: "Purchase is pending approval"])
        @unknown default:
            print("StoreKitManager: Unknown purchase result")
            throw NSError(domain: "StoreKitManager", code: 3, userInfo: [NSLocalizedDescriptionKey: "Unknown error occurred"])
        }
    }
    
    func canSendMessage() -> Bool {
        return messageCount > 0 || subscriptionTier == .premium
    }
    
    func decrementMessageCount() {
        if subscriptionTier != .premium && messageCount > 0 {
            messageCount -= 1
        }
    }
    
    func canPerformScan() -> Bool {
        return scanCount > 0 || subscriptionTier == .premium
    }
    
    func decrementScanCount() {
        if subscriptionTier != .premium && scanCount > 0 {
            scanCount -= 1
            print("StoreKitManager: Decremented scan count to: \(scanCount)")
        }
    }
    
    func canStoreAnalyses() -> Bool {
        return storingEnabled
    }
    
    func getRemainingMessages() -> String {
        if subscriptionTier == .premium {
            return "Unlimited"
        } else {
            return "\(messageCount)"
        }
    }
    
    func getRemainingScans() -> String {
        if subscriptionTier == .premium {
            return "Unlimited"
        } else {
            return "\(scanCount)"
        }
    }
    
    func handleRestoredTransactions() async {
        for await result in Transaction.currentEntitlements {
            if case .verified(let transaction) = result {
                // Handle the restored transaction
                handleVerifiedTransaction(transaction)
                
                // Important: Don't call transaction.finish() for restored transactions
                // They are already in the finished state
            }
        }
    }
    
    func restorePurchases() async throws {
        // First try to sync with App Store
        try await AppStore.sync()
        
        // Then handle any restored transactions
        await handleRestoredTransactions()
        
        // Update the subscription status
        await updateSubscriptionStatus()
    }
}
