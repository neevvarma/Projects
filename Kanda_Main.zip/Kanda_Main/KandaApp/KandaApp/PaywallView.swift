import SwiftUI
import StoreKit

struct PaywallView: View {
    @StateObject private var storeKitManager = StoreKitManager.shared
    @State private var isLoading = true
    @State private var errorMessage: String?
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        GeometryReader { geometry in
            ScrollView {
                VStack(spacing: 30) {
                    headerSection
                    
                    if isLoading {
                        loadingView
                            .frame(height: 200)
                    } else if let error = errorMessage {
                        errorView(error)
                    } else {
                        subscriptionOptionsView(geometry: geometry)
                    }
                    
                    restorePurchasesButton
                    
                    Spacer()
                        .frame(height: geometry.size.height * 0.05)
                    
                    privacySection
                        .padding(.bottom, 30)
                }
                .padding()
                .frame(minHeight: geometry.size.height)
            }
        }
        .background(Color.black.edgesIgnoringSafeArea(.all))
        .navigationBarTitle("Upgrade", displayMode: .inline)
        .navigationBarColor(backgroundColor: UIColor(Color.black), titleColor: UIColor(Color.white))
        .onAppear {
            print("PaywallView: onAppear")
            isLoading = storeKitManager.products.isEmpty
            if isLoading {
                Task {
                    print("PaywallView: Loading products")
                    await storeKitManager.loadProducts()
                    isLoading = false
                    print("PaywallView: Products loaded, count: \(storeKitManager.products.count)")
                }
            }
        }
    }
    
    private var headerSection: some View {
        VStack(spacing: 8) {
            Text("Unlock Premium")
                .font(.system(size: 32, weight: .bold))
                .multilineTextAlignment(.center)
                .padding(.top, 20)
                .foregroundColor(.white)
            
            Text("Choose a subscription plan:")
                .font(.headline)
                .foregroundColor(.gray)
        }
        .padding(.horizontal)
    }
    
    private var loadingView: some View {
        ProgressView()
            .progressViewStyle(CircularProgressViewStyle(tint: .white))
            .scaleEffect(1.5)
    }
    
    private func errorView(_ error: String) -> some View {
        Text(error)
            .foregroundColor(.red)
            .padding()
            .multilineTextAlignment(.center)
    }
    
    private var restorePurchasesButton: some View {
        Button(action: {
            Task {
                isLoading = true
                do {
                    try await AppStore.sync()
                    await storeKitManager.updateSubscriptionStatus()
                    if storeKitManager.subscriptionTier != .none {
                        dismiss()
                    } else {
                        errorMessage = "No previous purchases found to restore"
                    }
                } catch {
                    print("PaywallView: Restore purchase failed - Error: \(error.localizedDescription)")
                    errorMessage = "Failed to restore purchases: \(error.localizedDescription)"
                }
                isLoading = false
            }
        }) {
            HStack(spacing: 8) {
                Image(systemName: "arrow.clockwise.circle.fill")
                    .font(.system(size: 16))
                Text("Restore Purchases")
                    .font(.system(size: 16, weight: .medium))
            }
            .foregroundColor(.white)
            .padding(.vertical, 12)
            .padding(.horizontal, 24)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.gray.opacity(0.3))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color.white.opacity(0.1), lineWidth: 1)
                    )
            )
            .shadow(color: Color.black.opacity(0.2), radius: 4, x: 0, y: 2)
        }
        .buttonStyle(ScaleButtonStyle())
    }
    
    private var privacySection: some View {
        VStack(spacing: 12) {
            Text("By subscribing, you agree to our")
                .foregroundColor(.gray)
            
            HStack(spacing: 4) {
                Link("Terms of Service", destination: URL(string: "https://app.termly.io/policy-viewer/policy.html?policyUUID=ce7f3b8b-719e-438f-9c0a-8f655ef32c2a")!)
                    .foregroundColor(.blue)
                Text("and")
                    .foregroundColor(.gray)
                Link("Privacy Policy", destination: URL(string: "https://app.termly.io/policy-viewer/policy.html?policyUUID=a7b86c0a-7cc4-4a3b-8f16-1e87634cafb4")!)
                    .foregroundColor(.blue)
            }
            
            Text("Subscriptions automatically renew unless canceled")
                .foregroundColor(.gray)
                .padding(.top, 8)
        }
        .font(.caption)
        .multilineTextAlignment(.center)
        .padding(.horizontal)
    }
    
    private func subscriptionOptionsView(geometry: GeometryProxy) -> some View {
        VStack(spacing: 20) {
            if geometry.size.width > 700 {
                HStack(spacing: 20) {
                    subscriptionCards
                }
            } else {
                VStack(spacing: 20) {
                    subscriptionCards
                }
            }
        }
    }
    
    private var subscriptionCards: some View {
        Group {
            SubscriptionOption(
                title: "Basic",
                price: storeKitManager.products.first(where: { $0.id.contains("basic") })?.displayPrice ?? "$1.99/month",
                features: [
                    "1 full analysis with detailed breakdown",
                    "Workout and diet recommendations",
                    "3 chat messages",
                    "No storing"
                ],
                action: {
                    print("PaywallView: Basic subscription button tapped")
                    purchaseSubscription(for: .basic)
                }
            )
            
            SubscriptionOption(
                title: "Standard",
                price: storeKitManager.products.first(where: { $0.id.contains("standard") })?.displayPrice ?? "$3.99/month",
                features: [
                    "10 full analyses with detailed breakdown",
                    "Workout and diet recommendations",
                    "15 chat messages",
                    "Storing enabled"
                ],
                action: {
                    print("PaywallView: Standard subscription button tapped")
                    purchaseSubscription(for: .standard)
                }
            )
            
            SubscriptionOption(
                title: "Premium",
                price: storeKitManager.products.first(where: { $0.id.contains("premium") })?.displayPrice ?? "$7.99/month",
                features: [
                    "Unlimited full analyses",
                    "Workout and diet recommendations",
                    "Unlimited chat messages",
                    "Unlimited storing"
                ],
                action: {
                    print("PaywallView: Premium subscription button tapped")
                    purchaseSubscription(for: .premium)
                }
            )
        }
    }
    
    func purchaseSubscription(for tier: StoreKitManager.SubscriptionTier) {
        print("PaywallView: Attempting to purchase tier: \(tier.rawValue)")
        Task {
            do {
                try await storeKitManager.purchase(tier)
                print("PaywallView: Purchase successful for tier: \(tier.rawValue)")
                dismiss()
            } catch {
                print("PaywallView: Purchase failed for tier \(tier.rawValue) - Error: \(error.localizedDescription)")
                errorMessage = error.localizedDescription
            }
        }
    }
}

struct SubscriptionOption: View {
    let title: String
    let price: String
    let features: [String]
    let action: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(.headline)
                        .foregroundColor(.white)
                    
                    Text(price)
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
                
                Spacer()
                
                Button(action: action) {
                    Text("Select")
                        .font(.headline)
                        .padding(.vertical, 8)
                        .padding(.horizontal, 16)
                        .background(Color.white)
                        .foregroundColor(.black)
                        .cornerRadius(12)
                }
            }
            
            ForEach(features, id: \.self) { feature in
                HStack {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundColor(.white)
                    Text(feature)
                        .font(.caption)
                        .foregroundColor(.gray)
                }
            }
        }
        .padding()
        .background(Color.gray.opacity(0.2))
        .cornerRadius(15)
    }
}

struct ScaleButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.95 : 1)
            .animation(.easeInOut(duration: 0.2), value: configuration.isPressed)
    }
}

struct PaywallView_Previews: PreviewProvider {
    static var previews: some View {
        PaywallView()
    }
}
