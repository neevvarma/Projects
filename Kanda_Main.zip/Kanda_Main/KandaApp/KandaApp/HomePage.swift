import SwiftUI

struct HomePage: View {
    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.edgesIgnoringSafeArea(.all) // Background color for dark mode
                
                VStack(spacing: 30) {
                    Text("Welcome to Kanda!")
                        .font(.system(size: 40, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 20)
                                .fill(Color.white.opacity(0.05)) // Light white background with transparency
                                .shadow(color: .white.opacity(0.1), radius: 10, x: 0, y: 5)
                        )
                    
                    Spacer()
                    
                    Image(systemName: "figure.run.circle")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 150, height: 150)
                        .foregroundColor(.white)
                        .shadow(color: .white.opacity(0.3), radius: 10, x: 0, y: 5)
                    
                    Spacer()
                    
                    NavigationLink(destination: LandingScreen().environmentObject(UserData())) {
                        Text("Start Your Journey")
                            .font(.headline)
                            .foregroundColor(.black)
                            .padding()
                            .frame(minWidth: 200)
                            .background(Color.white) // White background for the button
                            .cornerRadius(10)
                    }
                    .buttonStyle(PlainButtonStyle())
                }
                .padding()
            }
        }
        .navigationBarTitle("Home", displayMode: .inline)
        .navigationBarColor(backgroundColor: UIColor(Color.black), titleColor: UIColor(Color.white))
    }
}

struct HomePage_Previews: PreviewProvider {
    static var previews: some View {
        HomePage()
    }
}
