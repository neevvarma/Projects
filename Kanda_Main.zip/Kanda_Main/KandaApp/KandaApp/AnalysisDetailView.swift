import SwiftUI

struct AnalysisDetailView: View {
    let analysis: SavedAnalysis
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("Analysis Date: \(analysis.folderName)")
                    .font(.headline)
                
                Text("Fitness Score: \(analysis.score)")
                    .font(.title)
                    .foregroundColor(.teal)
                
                Text("Detailed Analysis:")
                    .font(.headline)
                
                Text(analysis.analysis)
                    .font(.body)
                    .lineSpacing(8)
            }
            .padding()
        }
        .navigationTitle("Analysis Details")
    }
}
