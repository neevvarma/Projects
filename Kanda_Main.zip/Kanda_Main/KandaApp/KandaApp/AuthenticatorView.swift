//
//  AuthenticatorView.swift
//  KandaApp
//
//  Created by Aksheet Dutta on 8/22/24.
//
import LocalAuthentication
import SwiftUI
import UIKit

struct AuthenticatorView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    AuthenticatorView()
}
