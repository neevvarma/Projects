import SwiftUI

struct MainTabView: View {
    @ObservedObject var userData: UserData
    @EnvironmentObject var storeKitManager: StoreKitManager
    @State private var selectedTab = 0
    
    var body: some View {
        TabView(selection: $selectedTab) {
            NavigationStack {
                LandingScreen()
            }
            .tabItem {
                Image(systemName: "figure.walk")
                Text("Analysis")
            }
            .tag(0)
            
            NavigationStack {
                if storeKitManager.subscriptionTier != .none {
                    GeminiMultimodalChatApp()
                } else {
                    PaywallView()
                }
            }
            .tabItem {
                Image(systemName: "message")
                Text("Chat")
            }
            .tag(1)
            
            NavigationStack {
                if storeKitManager.subscriptionTier != .none {
                    SavedAnalysesView()
                } else {
                    PaywallView()
                }
            }
            .tabItem {
                Image(systemName: "folder")
                Text("Saved")
            }
            .tag(2)
            
            NavigationStack {
                HowToUseView()
            }
            .tabItem {
                Image(systemName: "questionmark.circle")
                Text("How to Use")
            }
            .tag(3)
        }
        .accentColor(.teal)
        .onAppear {
            // Set the tab bar appearance for iOS 15 and later
            let appearance = UITabBarAppearance()
            appearance.configureWithOpaqueBackground()
            appearance.backgroundColor = .black
            
            UITabBar.appearance().standardAppearance = appearance
            if #available(iOS 15.0, *) {
                UITabBar.appearance().scrollEdgeAppearance = appearance
            }
        }
    }
}

struct MainTabView_Previews: PreviewProvider {
    static var previews: some View {
        MainTabView(userData: UserData())
            .environmentObject(StoreKitManager.shared)
    }
}
