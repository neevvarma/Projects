//
//  ChatBubbleShape.swift
//  KandaApp
//
//  Created by Aksheet Dutta on 8/14/24.
//

import SwiftUI

struct ChatBubbleShape: Shape {
    enum Direction {
        case left
        case right
    }
    
    let direction: Direction
    
    func path(in rect: CGRect) -> Path {
        return (direction == .left) ? leftBubble(in: rect) : rightBubble(in: rect)
    }
    
    private func leftBubble(in rect: CGRect) -> Path {
        let width = rect.width
        let height = rect.height
        let cornerRadius: CGFloat = 16
        let tailWidth: CGFloat = 8
        let tailHeight: CGFloat = 10
        
        let path = Path { p in
            p.move(to: CGPoint(x: tailWidth, y: height - tailHeight))
            p.addLine(to: CGPoint(x: tailWidth, y: cornerRadius))
            p.addArc(center: CGPoint(x: tailWidth + cornerRadius, y: cornerRadius),
                     radius: cornerRadius,
                     startAngle: Angle.degrees(180),
                     endAngle: Angle.degrees(270),
                     clockwise: false)
            p.addLine(to: CGPoint(x: width - cornerRadius, y: 0))
            p.addArc(center: CGPoint(x: width - cornerRadius, y: cornerRadius),
                     radius: cornerRadius,
                     startAngle: Angle.degrees(270),
                     endAngle: Angle.degrees(0),
                     clockwise: false)
            p.addLine(to: CGPoint(x: width, y: height - cornerRadius))
            p.addArc(center: CGPoint(x: width - cornerRadius, y: height - cornerRadius),
                     radius: cornerRadius,
                     startAngle: Angle.degrees(0),
                     endAngle: Angle.degrees(90),
                     clockwise: false)
            p.addLine(to: CGPoint(x: tailWidth + cornerRadius, y: height))
            p.addArc(center: CGPoint(x: tailWidth + cornerRadius, y: height - tailHeight),
                     radius: cornerRadius,
                     startAngle: Angle.degrees(90),
                     endAngle: Angle.degrees(135),
                     clockwise: false)
            p.addLine(to: CGPoint(x: 0, y: height))
            p.addLine(to: CGPoint(x: tailWidth, y: height - tailHeight))
        }
        return path
    }
    
    private func rightBubble(in rect: CGRect) -> Path {
        let width = rect.width
        let height = rect.height
        let cornerRadius: CGFloat = 16
        let tailWidth: CGFloat = 8
        let tailHeight: CGFloat = 10
        
        let path = Path { p in
            p.move(to: CGPoint(x: width - tailWidth, y: height - tailHeight))
            p.addLine(to: CGPoint(x: width - tailWidth, y: cornerRadius))
            p.addArc(center: CGPoint(x: width - tailWidth - cornerRadius, y: cornerRadius),
                     radius: cornerRadius,
                     startAngle: Angle.degrees(0),
                     endAngle: Angle.degrees(270),
                     clockwise: true)
            p.addLine(to: CGPoint(x: cornerRadius, y: 0))
            p.addArc(center: CGPoint(x: cornerRadius, y: cornerRadius),
                     radius: cornerRadius,
                     startAngle: Angle.degrees(270),
                     endAngle: Angle.degrees(180),
                     clockwise: true)
            p.addLine(to: CGPoint(x: 0, y: height - cornerRadius))
            p.addArc(center: CGPoint(x: cornerRadius, y: height - cornerRadius),
                     radius: cornerRadius,
                     startAngle: Angle.degrees(180),
                     endAngle: Angle.degrees(90),
                     clockwise: true)
            p.addLine(to: CGPoint(x: width - tailWidth - cornerRadius, y: height))
            p.addArc(center: CGPoint(x: width - tailWidth - cornerRadius, y: height - tailHeight),
                     radius: cornerRadius,
                     startAngle: Angle.degrees(90),
                     endAngle: Angle.degrees(45),
                     clockwise: true)
            p.addLine(to: CGPoint(x: width, y: height))
            p.addLine(to: CGPoint(x: width - tailWidth, y: height - tailHeight))
        }
        return path
    }
}
