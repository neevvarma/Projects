import Foundation
import SwiftUI
import GoogleGenerativeAI

class ChatBotApp {
    private var chat: Chat?
    @EnvironmentObject var userData: UserData
    private(set) var messages = [ChatMessage]()
    private(set) var loadingResponse = false
    
    func sendMessage(_ message: String) {
        loadingResponse = true
        
        if (chat == nil) {
            let history: [ModelContent] = messages.map { ModelContent(role: $0.role == .user ? "user" : "model", parts: $0.message)}
            chat = GenerativeModel(name: "gemini-pro", apiKey: "", systemInstruction: "You know the user information as follows. This is the user's details: Age = \(userData.age), Height = \(userData.heightFeet) ft \(userData.heightInches) in, Weight = \(userData.weight) lbs, Physical Activity level = \(userData.physicalActivity), Region Temperature = \(userData.regionTemperature), Occupation = \(userData.occupation), How much of the body they want analyzed = \(userData.analysisChoice). Make your responses short, as you should act like a fitness trainer friend that is casually texting the user. Provide helpful responses to what they are asking about.").startChat(history: history)
        }
        
        // MARK: Add user's message to the list
        messages.append(.init(role: .user, message: message))
        
        Task {
            do {
                let response = try await chat?.sendMessage(message)
                
                loadingResponse = false
                
                guard let text = response?.text else {
                    messages.append(.init(role: .model, message: "Something went wrong, please try again."))
                    return
                }
                
                messages.append(.init(role: .model, message: text))
            }
            catch {
                loadingResponse = false
                messages.append(.init(role: .model, message: "Something went wrong, please try again."))
            }
        }
    }
}
