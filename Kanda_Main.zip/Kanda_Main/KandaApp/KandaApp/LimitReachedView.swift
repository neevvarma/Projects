import SwiftUI

struct LimitReachedView: View {
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var storeKitManager: StoreKitManager
    @Binding var showingPaywall: Bool
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Limit Reached")
                .font(.system(size: 28, weight: .bold))
                .foregroundColor(.white)
            
            Text("You've reached your message limit.")
                .font(.headline)
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
            
            Text("Upgrade your plan to send more messages.")
                .font(.subheadline)
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
            
            Button(action: {
                showingPaywall = true
                presentationMode.wrappedValue.dismiss()
            }) {
                Text("Upgrade Now")
                    .font(.headline)
                    .foregroundColor(.black)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.white)
                    .cornerRadius(10)
            }
            
            Button(action: {
                presentationMode.wrappedValue.dismiss()
            }) {
                Text("Maybe Later")
                    .font(.headline)
                    .foregroundColor(.white)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black.edgesIgnoringSafeArea(.all))
    }
}
