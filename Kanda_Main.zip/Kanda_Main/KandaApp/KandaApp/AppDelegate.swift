//
//  AppDelegate.swift
//  KandaApp
//
//  Created by Aksheet Dutta on 9/3/24.
//
import UIKit
import AppsFlyerLib


class AppDelegate: UIResponder, UIApplicationDelegate, AppsFlyerLibDelegate {

    // Define your App ID and Dev Key
    let appsFlyerDevKey = "YOUR_DEV_KEY"
    let appleAppID = "YOUR_APP_ID"
    
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Initialize AppsFlyer
        AppsFlyerLib.shared().appsFlyerDevKey = appsFlyerDevKey
        AppsFlyerLib.shared().appleAppID = appleAppID
        AppsFlyerLib.shared().delegate = self
        AppsFlyerLib.shared().isDebug = true // Enable for debugging

        // Start AppsFlyer SDK tracking
        AppsFlyerLib.shared().start()
        
        return true
    }

    // MARK: - AppsFlyerLibDelegate Methods

    // Implement AppsFlyerLibDelegate methods for handling deep links and referrals
    func onConversionDataSuccess(_ conversionInfo: [AnyHashable: Any]) {
        print("Conversion data success: \(conversionInfo)")
    }

    func onConversionDataFail(_ error: Error) {
        print("Conversion data failed: \(error.localizedDescription)")
    }

    func onAppOpenAttribution(_ attributionData: [AnyHashable: Any]) {
        print("App open attribution: \(attributionData)")
    }

    func onAppOpenAttributionFailure(_ error: Error) {
        print("App open attribution failed: \(error.localizedDescription)")
    }

    // Handle open URL to support deferred deep linking
    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey: Any] = [:]) -> Bool {
        AppsFlyerLib.shared().handleOpen(url, options: options)
        return true
    }

    // Handle universal links
    func application(_ application: UIApplication, continue userActivity: NSUserActivity,
                     restorationHandler: @escaping ([UIUserActivityRestoring]?) -> Void) -> Bool {
        AppsFlyerLib.shared().continue(userActivity, restorationHandler: nil)
        return true
    }
}
