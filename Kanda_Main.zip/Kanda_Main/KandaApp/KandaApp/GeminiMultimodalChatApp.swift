import SwiftUI
import PhotosUI

struct GeminiMultimodalChatApp: View {
    @State private var textInput = ""
    @StateObject private var chatService = ChatService()
    @State private var photoPickerItems = [PhotosPickerItem]()
    @State private var selectedPhotoData = [Data]()
    @StateObject private var storeKitManager = StoreKitManager.shared
    @State private var showingPaywall = false
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Color.black.edgesIgnoringSafeArea(.all)
                
                VStack(spacing: 0) {
                    chatMessageList
                        .frame(height: geometry.size.height * 0.7)
                    Divider()
                        .background(Color.gray.opacity(0.3))
                    imagePreview
                        .frame(height: geometry.size.height * 0.1)
                    inputFields
                        .frame(height: geometry.size.height * 0.2)
                }
            }
        }
        .sheet(isPresented: $showingPaywall) {
            PaywallView()
        }
        .navigationBarTitle("Chat", displayMode: .inline)
        .navigationBarColor(backgroundColor: UIColor(Color.black), titleColor: UIColor(Color.white))
    }
    
    private var chatMessageList: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 20) {
                    ForEach(chatService.messages) { chatMessage in
                        chatMessageView(chatMessage)
                    }
                }
                .padding(.horizontal)
                .padding(.top, 20)
            }
            .onChange(of: chatService.messages) { _ in
                scrollToBottom(proxy: proxy)
            }
        }
    }
    
    private var imagePreview: some View {
        Group {
            if !selectedPhotoData.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    LazyHStack(spacing: 10) {
                        ForEach(selectedPhotoData.indices, id: \.self) { index in
                            Image(uiImage: UIImage(data: selectedPhotoData[index])!)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 60, height: 60)
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color.white.opacity(0.5), lineWidth: 1)
                                )
                        }
                    }
                    .padding(.horizontal)
                }
                .frame(height: 70)
                .padding(.vertical, 10)
            }
        }
    }
    
    private var inputFields: some View {
        HStack(spacing: 12) {
            photosPicker
            
            TextField("", text: $textInput)
                .placeholder(when: textInput.isEmpty) {
                    Text("Type a message...")
                        .foregroundColor(Color.gray.opacity(0.6))
                }
                .textFieldStyle(ModernTextFieldStyle())
                .foregroundColor(.white)
            
            Button(action: sendMessage) {
                Image(systemName: chatService.loadingResponse ? "ellipsis" : "arrow.up")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(.black)
                    .frame(width: 30, height: 30)
                    .background(Color.white)
                    .clipShape(Circle())
            }
            .disabled(textInput.isEmpty && selectedPhotoData.isEmpty)
        }
        .padding(.horizontal)
        .padding(.vertical, 10)
        .background(Color.gray.opacity(0.1))
    }
    
    private var photosPicker: some View {
        PhotosPicker(selection: $photoPickerItems, maxSelectionCount: 3, matching: .images) {
            Image(systemName: "photo")
                .font(.system(size: 14, weight: .bold))
                .foregroundColor(.white)
                .frame(width: 30, height: 30)
                .background(Color.gray.opacity(0.3))
                .clipShape(Circle())
        }
        .onChange(of: photoPickerItems) { _ in
            Task {
                selectedPhotoData.removeAll()
                for item in photoPickerItems {
                    if let imageData = try await item.loadTransferable(type: Data.self) {
                        selectedPhotoData.append(imageData)
                    }
                }
            }
        }
    }
    
    @ViewBuilder private func chatMessageView(_ message: ChatMessage) -> some View {
        HStack {
            if message.role == .user { Spacer() }
            VStack(alignment: message.role == .user ? .trailing : .leading, spacing: 5) {
                if let images = message.images, !images.isEmpty {
                    imageCarousel(images: images)
                }
                Text(message.message)
                    .font(.custom("ProximaNova-Light", size: 16))
                    .foregroundColor(message.role == .user ? .white : .black)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(message.role == .user ? Color.gray.opacity(0.3) : Color.white)
                    .clipShape(RoundedRectangle(cornerRadius: 18))
            }
            .frame(maxWidth: UIScreen.main.bounds.width * 0.7, alignment: message.role == .user ? .trailing : .leading)
            if message.role == .model { Spacer() }
        }
    }
    
    private func imageCarousel(images: [Data]) -> some View {
        ScrollView(.horizontal, showsIndicators: false) {
            LazyHStack(spacing: 10) {
                ForEach(images.indices, id: \.self) { index in
                    Image(uiImage: UIImage(data: images[index])!)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 200, height: 150)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.white.opacity(0.5), lineWidth: 1)
                        )
                }
            }
        }
        .frame(height: 150)
    }
    
    private func sendMessage() {
        if storeKitManager.canSendMessage() {
            Task {
                await chatService.sendMessage(message: textInput, imageData: selectedPhotoData)
                selectedPhotoData.removeAll()
                textInput = ""
                storeKitManager.decrementMessageCount()
            }
        } else {
            showingPaywall = true
        }
    }
    
    private func scrollToBottom(proxy: ScrollViewProxy) {
        guard let lastMessage = chatService.messages.last else { return }
        DispatchQueue.main.async {
            withAnimation {
                proxy.scrollTo(lastMessage.id, anchor: .bottom)
            }
        }
    }
}

struct ModernTextFieldStyle: TextFieldStyle {
    func _body(configuration: TextField<Self._Label>) -> some View {
        configuration
            .padding(.vertical, 12)
            .padding(.horizontal, 10)
            .background(Color.gray.opacity(0.2))
            .cornerRadius(20)
    }
}

extension View {
    func placeholder<Content: View>(
        when shouldShow: Bool,
        alignment: Alignment = .leading,
        @ViewBuilder placeholder: () -> Content) -> some View {

        ZStack(alignment: alignment) {
            placeholder().opacity(shouldShow ? 1 : 0)
            self
        }
    }
}

struct GeminiMultimodalChatApp_Previews: PreviewProvider {
    static var previews: some View {
        GeminiMultimodalChatApp()
            .environmentObject(StoreKitManager.shared)
    }
}
