import SwiftUI

struct LandingScreen: View {
    @EnvironmentObject var userData: UserData
    @State private var showingImagePicker = false
    @State private var selectedImages: [UIImage] = []
    @State private var showTermsAndConditions = true
    @State private var hasAgreedToTerms = false
    
    let physicalActivityOptions = ["Sedentary", "Moderately Active", "Vigorously Active"]
    let regionTemperatureOptions = ["Always Cold", "Moderate", "Always Hot"]
    let occupationOptions = ["Desk Job", "Active Occupation"]
    let analysisOption = ["Full Body Analysis", "Upper Body Only"]
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Color.black.edgesIgnoringSafeArea(.all)
                
                ScrollView {
                    VStack(spacing: 20) {
                        Text("Enter Your Details")
                            .font(.custom("ProximaNova-Bold", size: geometry.size.width > 700 ? 40 : 30))
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .center)
                        
                        if geometry.size.width > 700 {
                            HStack(alignment: .top, spacing: 40) {
                                VStack {
                                    Group {
                                        futuristicPicker(title: "Age", selection: $userData.age, range: 18...100)
                                        heightPicker
                                        futuristicPicker(title: "Weight (lbs)", selection: $userData.weight, range: 100...299)
                                    }
                                }
                                VStack {
                                    Group {
                                        futuristicSegmentedPicker(title: "Physical Activity Level", selection: $userData.physicalActivity, options: physicalActivityOptions)
                                        futuristicSegmentedPicker(title: "Region Temperature", selection: $userData.regionTemperature, options: regionTemperatureOptions)
                                        futuristicSegmentedPicker(title: "Occupation", selection: $userData.occupation, options: occupationOptions)
                                        futuristicSegmentedPicker(title: "Analysis Option", selection: $userData.analysisChoice, options: analysisOption)
                                    }
                                }
                            }
                        } else {
                            Group {
                                futuristicPicker(title: "Age", selection: $userData.age, range: 18...100)
                                heightPicker
                                futuristicPicker(title: "Weight (lbs)", selection: $userData.weight, range: 100...299)
                            }
                            Group {
                                futuristicSegmentedPicker(title: "Physical Activity Level", selection: $userData.physicalActivity, options: physicalActivityOptions)
                                futuristicSegmentedPicker(title: "Region Temperature", selection: $userData.regionTemperature, options: regionTemperatureOptions)
                                futuristicSegmentedPicker(title: "Occupation", selection: $userData.occupation, options: occupationOptions)
                                futuristicSegmentedPicker(title: "Analysis Option", selection: $userData.analysisChoice, options: analysisOption)
                            }
                        }
                        
                        Button(action: {
                            showingImagePicker = true
                        }) {
                            Text("Select Images")
                                .font(.custom("ProximaNova-Bold", size: 18))
                                .frame(maxWidth: .infinity)
                                .frame(height: 50)
                                .background(Color.white)
                                .foregroundColor(.black)
                                .cornerRadius(10)
                        }
                        .buttonStyle(PlainButtonStyle())
                        .disabled(!hasAgreedToTerms)
                        
                        if !selectedImages.isEmpty {
                            Text("Selected Images:")
                                .font(.custom("ProximaNova-Bold", size: 18))
                                .foregroundColor(.white)
                            
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack {
                                    ForEach(selectedImages.indices, id: \.self) { index in
                                        Image(uiImage: selectedImages[index])
                                            .resizable()
                                            .scaledToFit()
                                            .frame(height: 100)
                                            .cornerRadius(10)
                                            .overlay(
                                                Button(action: {
                                                    selectedImages.remove(at: index)
                                                }) {
                                                    Image(systemName: "xmark.circle.fill")
                                                        .foregroundColor(.red)
                                                        .background(Color.white)
                                                        .clipShape(Circle())
                                                }
                                                .offset(x: 5, y: -5),
                                                alignment: .topTrailing
                                            )
                                    }
                                }
                            }
                        }
                        
                        NavigationLink(destination: MultimodalChatView(images: selectedImages).environmentObject(userData)) {
                            Text("Proceed")
                                .font(.custom("ProximaNova-Bold", size: 18))
                                .frame(maxWidth: .infinity)
                                .frame(height: 50)
                                .background(Color.white)
                                .foregroundColor(.black)
                                .cornerRadius(10)
                        }
                        .buttonStyle(PlainButtonStyle())
                        .disabled(!hasAgreedToTerms)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .center)
                }
            }
        }
        .navigationBarTitle("User Information", displayMode: .inline)
        .navigationBarColor(backgroundColor: UIColor(Color.black), titleColor: UIColor(Color.white))
        .sheet(isPresented: $showingImagePicker) {
            ImagePickerView(selectedImages: $selectedImages)
        }
        .fullScreenCover(isPresented: $showTermsAndConditions, content: {
            TermsAndConditionsPopup(hasAgreed: $hasAgreedToTerms, showTermsAndConditions: $showTermsAndConditions)
        })
    }
    
    private var heightPicker: some View {
        VStack(alignment: .center) {
            Text("Height").font(.custom("ProximaNova-Bold", size: 18)).foregroundColor(.white)
            
            HStack {
                futuristicPicker(title: "Feet", selection: $userData.heightFeet, range: 3...8)
                futuristicPicker(title: "Inches", selection: $userData.heightInches, range: 0...11)
            }
            .frame(maxWidth: .infinity, alignment: .center)
        }
    }
    
    private func futuristicPicker(title: String, selection: Binding<Int>, range: ClosedRange<Int>) -> some View {
        VStack(alignment: .center) {
            Text(title).font(.custom("ProximaNova-Bold", size: 18)).foregroundColor(.white)
            Picker(title, selection: selection) {
                ForEach(range, id: \.self) { number in
                    Text("\(number)")
                        .tag(number)
                }
            }
            .pickerStyle(WheelPickerStyle())
            .frame(height: 100)
            .clipped()
            .background(Color.white.opacity(0.1))
            .cornerRadius(10)
            .environment(\.colorScheme, .dark)
        }
        .frame(maxWidth: .infinity, alignment: .center)
    }

    private func futuristicSegmentedPicker(title: String, selection: Binding<String>, options: [String]) -> some View {
        VStack(alignment: .center) {
            Text(title).font(.custom("ProximaNova-Bold", size: 18)).foregroundColor(.white)
            Picker(title, selection: selection) {
                ForEach(options, id: \.self) { option in
                    Text(option)
                }
            }
            .pickerStyle(SegmentedPickerStyle())
            .background(Color.white.opacity(0.1))
            .cornerRadius(10)
        }
        .accentColor(.white)
        .frame(maxWidth: .infinity, alignment: .center)
    }
}

struct TermsAndConditionsPopup: View {
    @Binding var hasAgreed: Bool
    @Binding var showTermsAndConditions: Bool
    
    var body: some View {
        VStack(spacing: 15) {
            Text("How to Use Kanda")
                .font(.custom("ProximaNova-Bold", size: 24))
                .foregroundColor(.white)
            
            ScrollView {
                VStack(alignment: .leading, spacing: 15) {
                    instructionsView
                    
                    Divider().background(Color.white)
                    
                    healthDisclaimerView
                    
                    Divider().background(Color.white)
                    
                    Text("Terms and Conditions")
                        .font(.custom("ProximaNova-Bold", size: 20))
                        .foregroundColor(.white)
                    
                    Text("Please read and accept the terms and conditions before proceeding.")
                        .font(.custom("ProximaNova-Light", size: 16))
                        .foregroundColor(.white)
                    
                    VStack(spacing: 10) {
                        Link(destination: URL(string: "https://app.termly.io/policy-viewer/policy.html?policyUUID=ce7f3b8b-719e-438f-9c0a-8f655ef32c2a")!, label: {
                            Label("Terms and Conditions", systemImage: "doc.text")
                                .font(.custom("ProximaNova-Light", size: 16))
                                .frame(maxWidth: .infinity)
                                .frame(height: 40)
                                .background(Color.white)
                                .foregroundColor(.black)
                                .cornerRadius(8)
                        })
                        
                        Link(destination: URL(string:"https://app.termly.io/policy-viewer/policy.html?policyUUID=a7b86c0a-7cc4-4a3b-8f16-1e87634cafb4")!, label: {
                            Label("Privacy Policy", systemImage: "lock.fill")
                                .font(.custom("ProximaNova-Light", size: 16))
                                .frame(maxWidth: .infinity)
                                .frame(height: 40)
                                .background(Color.white)
                                .foregroundColor(.black)
                                .cornerRadius(8)
                        })
                    }
                }
                .padding(.horizontal)
            }
            .frame(height: UIScreen.main.bounds.height * 0.6)
            
            Toggle(isOn: $hasAgreed) {
                Text("I agree to the terms and conditions")
                    .font(.custom("ProximaNova-Bold", size: 16))
                    .foregroundColor(.white)
            }
            .padding(.horizontal)
            
            Button(action: {
                if hasAgreed {
                    showTermsAndConditions = false
                }
            }) {
                Text("Continue")
                    .font(.custom("ProximaNova-Bold", size: 18))
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    .background(hasAgreed ? Color.white : Color.gray)
                    .foregroundColor(.black)
                    .cornerRadius(10)
            }
            .disabled(!hasAgreed)
            .padding(.horizontal)
        }
        .padding()
        .background(Color.black)
        .cornerRadius(20)
        .frame(maxWidth: 400)
    }
    
    private var instructionsView: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Instructions")
                .font(.custom("ProximaNova-Bold", size: 20))
                .foregroundColor(.white)
            
            instructionText("1. Take pictures in JPEG form by going to Settings > Camera > Formats and select 'Most Compatible'.")
            instructionText("2. Take a picture of your front side while flexing your arms then one with muscles relaxed. Repeat the process for your back side too.")
            instructionText("3. Wait for the analysis to run, it can take up to a minute, so please be patient.")
            instructionText("4. The chatbot can be used for many different tasks, such as creating customized meal plans, personalized workouts, and interpreting personal health information.")
            
            Text("We do not store or share your data")
                .font(.custom("ProximaNova-Bold", size: 18))
                .foregroundColor(.white)
                .padding()
                .background(Color.black)
                .cornerRadius(10)
        }
    }
    
    private var healthDisclaimerView: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Health Disclaimer")
                .font(.custom("ProximaNova-Bold", size: 20))
                .foregroundColor(.white)
            
            Text("Please seek a doctor's advice in addition to using this app and before making any medical decisions. The health analysis and insights provided by this app are for informational and educational purposes only. They are not intended to be a substitute for professional medical advice, diagnosis, or treatment.")
                .font(.custom("ProximaNova-Light", size: 16))
                .foregroundColor(.white)
            
            Text("Contact us: contact@kandaapp.com")
                .font(.custom("ProximaNova-Light", size: 16))
                .foregroundColor(.white)
                .padding(.top, 5)
        }
    }
    
    private func instructionText(_ text: String) -> some View {
        Text(text)
            .font(.custom("ProximaNova-Light", size: 16))
            .foregroundColor(.white)
    }
}

struct LandingScreen_Previews: PreviewProvider {
    static var previews: some View {
        LandingScreen().environmentObject(UserData())
    }
}
