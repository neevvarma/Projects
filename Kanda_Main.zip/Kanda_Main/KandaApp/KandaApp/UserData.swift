import Foundation

class UserData: ObservableObject {
    @Published var age: Int = 18
    @Published var heightFeet: Int = 5
    @Published var heightInches: Int = 0
    @Published var weight: Int = 60
    @Published var physicalActivity: String = "Sedentary"
    @Published var regionTemperature: String = "Always Cold"
    @Published var occupation: String = "Desk Job"
    @Published var analysisChoice: String = "Full Body Analysis"
    @Published var savedAnalyses: [SavedAnalysis] = []
    
    var heightInTotalInches: Int {
        return (heightFeet * 12) + heightInches
    }
    
    init() {
        loadSavedAnalyses()
    }
    
    func saveAnalysis(_ analysis: SavedAnalysis) {
        savedAnalyses.append(analysis)
        saveSavedAnalyses()
    }
    
    func deleteAnalysis(at offsets: IndexSet) {
        savedAnalyses.remove(atOffsets: offsets)
        saveSavedAnalyses()
    }
    
    private func saveSavedAnalyses() {
        if let encoded = try? JSONEncoder().encode(savedAnalyses) {
            UserDefaults.standard.set(encoded, forKey: "savedAnalyses")
        }
    }
    
    private func loadSavedAnalyses() {
        if let savedAnalyses = UserDefaults.standard.data(forKey: "savedAnalyses"),
           let decodedAnalyses = try? JSONDecoder().decode([SavedAnalysis].self, from: savedAnalyses) {
            self.savedAnalyses = decodedAnalyses
        }
    }
}

struct SavedAnalysis: Identifiable, Codable {
    let id: UUID
    let date: Date
    let score: String
    let analysis: String
    
    var folderName: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        return formatter.string(from: date)
    }
    
    init(id: UUID = UUID(), date: Date = Date(), score: String, analysis: String) {
        self.id = id
        self.date = date
        self.score = score
        self.analysis = analysis
    }
}
