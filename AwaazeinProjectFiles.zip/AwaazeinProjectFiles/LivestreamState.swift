import SwiftUI

class LivestreamState: ObservableObject {
    @Published var isPreviewMode = false
    
    static let shared = LivestreamState()
    private init() {}
}
