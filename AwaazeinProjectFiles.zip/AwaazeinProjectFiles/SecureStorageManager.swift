import Foundation
import CryptoKit
import FirebaseDatabase

class SecureStorageManager {
    static let shared = SecureStorageManager()
    private let adminCredentialsKey = "adminCredentialsKey"
    private let livestreamLinkKey = "livestreamLink"
    
    private init() {}
    
    // Hash a password securely
    private func hashPassword(_ password: String) -> String {
        let inputData = Data(password.utf8)
        let hashedData = SHA256.hash(data: inputData)
        return hashedData.compactMap { String(format: "%02x", $0) }.joined()
    }
    
    // Set admin credentials (should be done only once)
    func setAdminCredentials(password: String) {
        let hashedPassword = hashPassword(password)
        UserDefaults.standard.set(hashedPassword, forKey: adminCredentialsKey)
    }
    
    // Validate admin credentials
    func validateAdminCredentials(password: String) -> Bool {
        guard let storedHash = UserDefaults.standard.string(forKey: adminCredentialsKey) else {
            return false
        }
        return storedHash == hashPassword(password)
    }
    
    // Store livestream link locally and in Firebase
    func updateLivestreamLink(_ link: String) {
        // Store locally
        UserDefaults.standard.set(link, forKey: livestreamLinkKey)
        
        // Update in Firebase
        Database.database().reference().child("livestream").child("currentVideoID").setValue(link) { error, _ in
            if let error = error {
                print("Error updating livestream link: \(error.localizedDescription)")
            } else {
                print("Successfully updated livestream link")
            }
        }
        
        // Post a notification when the link is updated
        NotificationCenter.default.post(name: .livestreamLinkUpdated, object: nil)
    }
    
    // Retrieve livestream link
    func getLivestreamLink() -> String? {
        return UserDefaults.standard.string(forKey: livestreamLinkKey)
    }
}

// Notification extension for livestream link updates
extension Notification.Name {
    static let livestreamLinkUpdated = Notification.Name("livestreamLinkUpdated")
}
