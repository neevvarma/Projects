import SwiftUI
import FirebaseCore

class AppDelegate: NSObject, UIApplicationDelegate {
    static let shared = AppDelegate()
    
    // Static variable to control orientation lock
    static var orientationLock = UIInterfaceOrientationMask.portrait
    
    private override init() {
        super.init()
    }
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        // Standard Firebase configuration
        FirebaseApp.configure()
        return true
    }
    
    // Override to enforce portrait mode
    func application(_ application: UIApplication, supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
        return AppDelegate.orientationLock
    }
}

@main
struct AwaazeinApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    @AppStorage("hasCompletedFirstLaunch") private var hasCompletedFirstLaunch = false
    
    init() {
        // Absolutely NO Firebase configuration here
        
        // Customize the appearance of the tab bar
        CasinoTabBarAppearance.configure()
    }
    
    var body: some Scene {
        WindowGroup {
            if hasCompletedFirstLaunch {
                LoadingScreenView()
                    .onAppear {
                        // Lock orientation to portrait when LoadingScreenView appears
                        AppDelegate.orientationLock = .portrait
                    }
                    .onDisappear {
                        // Unlock orientation when LoadingScreenView disappears
                        AppDelegate.orientationLock = .all
                    }
            } else {
                FirstLaunchView(hasCompletedFirstLaunch: $hasCompletedFirstLaunch)
                    .onAppear {
                        // Lock orientation to portrait when FirstLaunchView appears
                        AppDelegate.orientationLock = .portrait
                    }
            }
        }
    }
}
