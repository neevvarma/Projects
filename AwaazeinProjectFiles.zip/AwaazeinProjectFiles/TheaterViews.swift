import SwiftUI

struct TheaterCeiling: View {
    var body: some View {
        Path { path in
            path.move(to: CGPoint(x: 0, y: 50))
            path.addCurve(
                to: CGPoint(x: UIScreen.main.bounds.width, y: 50),
                control1: CGPoint(x: UIScreen.main.bounds.width * 0.3, y: 0),
                control2: CGPoint(x: UIScreen.main.bounds.width * 0.7, y: 0)
            )
        }
        .fill(
            LinearGradient(
                colors: [AppColors.deepMaroon, AppColors.nightBlack],
                startPoint: .top,
                endPoint: .bottom
            )
        )
        .frame(height: 50)
    }
}

struct TheaterWall: View {
    var body: some View {
        GeometryReader { geometry in
            Path { path in
                let patternSize: CGFloat = 30
                for x in stride(from: 0, through: geometry.size.width, by: patternSize) {
                    for y in stride(from: 0, through: geometry.size.height, by: patternSize) {
                        path.move(to: CGPoint(x: x, y: y))
                        path.addLine(to: CGPoint(x: x + patternSize/2, y: y + patternSize/2))
                    }
                }
            }
            .stroke(AppColors.richGold.opacity(0.1), lineWidth: 1)
        }
    }
}

struct TheaterCurtain: View {
    enum Side {
        case left, right
    }
    
    let side: Side
    let isOpen: Bool
    
    var body: some View {
        Rectangle()
            .fill(
                LinearGradient(
                    colors: [AppColors.deepMaroon, AppColors.deepMaroon.opacity(0.8)],
                    startPoint: side == .left ? .trailing : .leading,
                    endPoint: side == .left ? .leading : .trailing
                )
            )
            .frame(maxWidth: .infinity)
            .overlay(
                TheaterCurtainPattern()
                    .opacity(0.3)
            )
            .offset(x: isOpen ? (side == .left ? -UIScreen.main.bounds.width : UIScreen.main.bounds.width) : 0)
    }
}

struct TheaterCurtainPattern: View {
    var body: some View {
        GeometryReader { geometry in
            Path { path in
                let width = geometry.size.width
                let height = geometry.size.height
                let patternSize: CGFloat = 40
                
                for x in stride(from: 0, through: width, by: patternSize) {
                    for y in stride(from: 0, through: height, by: patternSize) {
                        let rect = CGRect(x: x, y: y, width: 2, height: 2)
                        path.addEllipse(in: rect)
                    }
                }
            }
            .fill(AppColors.richGold)
        }
    }
}

struct TheaterSeats: View {
    var body: some View {
        HStack(spacing: 5) {
            ForEach(0..<8) { row in
                Circle()
                    .fill(AppColors.richGold.opacity(0.3))
                    .frame(width: 20, height: 20)
            }
        }
        .padding(.bottom, 30)
    }
}
