import SwiftUI
import AVKit

struct FirstLaunchView: View {
    @State private var player: AVPlayer?
    @Binding var hasCompletedFirstLaunch: Bool
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            if let player = player {
                AVPlayerControllerRepresentable(player: player, onEnd: {
                    hasCompletedFirstLaunch = true
                })
                .ignoresSafeArea()
            }
        }
        .onAppear {
            setupVideoPlayer()
        }
    }
    
    private func setupVideoPlayer() {
        guard let url = Bundle.main.url(forResource: "awaazein_intro", withExtension: "mp4") else {
            hasCompletedFirstLaunch = true
            return
        }
        
        player = AVPlayer(url: url)
    }
}

struct AVPlayerControllerRepresentable: UIViewControllerRepresentable {
    let player: AVPlayer
    let onEnd: () -> Void
    
    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.player = player
        controller.showsPlaybackControls = false
        controller.videoGravity = .resizeAspectFill
        
        // Add observer for video end
        NotificationCenter.default.addObserver(
            context.coordinator,
            selector: #selector(Coordinator.playerDidFinishPlaying),
            name: .AVPlayerItemDidPlayToEndTime,
            object: player.currentItem
        )
        
        return controller
    }
    
    func updateUIViewController(_ uiViewController: AVPlayerViewController, context: Context) {
        player.play()
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject {
        var parent: AVPlayerControllerRepresentable
        
        init(_ parent: AVPlayerControllerRepresentable) {
            self.parent = parent
        }
        
        @objc func playerDidFinishPlaying() {
            DispatchQueue.main.async {
                self.parent.onEnd()
            }
        }
    }
}
