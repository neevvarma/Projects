import SwiftUI
import AVKit

struct VideoPlayerWithFullScreen: View {
    let url: URL
    @State private var isFullScreen = false
    @State private var player: AVPlayer?
    
    var body: some View {
        VStack(spacing: 0) {
            // Video Player
            VideoPlayer(player: player)
                .frame(height: isFullScreen ? UIScreen.main.bounds.height : UIScreen.main.bounds.width * 9/16)
                .aspectRatio(16/9, contentMode: .fit)
            
            // Full Screen Button
            Button(action: {
                isFullScreen.toggle()
            }) {
                HStack {
                    Image(systemName: isFullScreen ? "arrow.down.right.and.arrow.up.left" : "arrow.up.left.and.arrow.down.right")
                    Text(isFullScreen ? "Exit Full Screen" : "Full Screen")
                }
                .foregroundColor(AppColors.richGold)
                .padding()
            }
        }
        .onAppear {
            player = AVPlayer(url: url)
            player?.play()
        }
        .onDisappear {
            player?.pause()
            player = nil
        }
    }
}
