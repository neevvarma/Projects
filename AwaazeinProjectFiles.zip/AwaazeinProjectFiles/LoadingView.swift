import SwiftUI

struct LoadingView: View {
    @State private var isAnimating = false
    
    var body: some View {
        VStack {
            Circle()
                .fill(AppColors.richGold)
                .frame(width: 50, height: 50)
                .scaleEffect(isAnimating ? 1.0 : 0.5)
                .animation(
                    Animation.easeInOut(duration: 0.25)
                        .repeatForever(autoreverses: true),
                    value: isAnimating
                )
        }
        .onAppear {
            isAnimating = true
        }
    }
}
