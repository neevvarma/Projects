import SwiftUI

struct ParticleSystem: View {
    let count: Int
    @State private var time: Double = 0
    
    var body: some View {
        TimelineView(.animation) { timeline in
            Canvas { context, size in
                for i in 0..<count {
                    let position = particlePosition(index: i, time: time, size: size)
                    let alpha = (sin(time + Double(i)) + 1) / 2
                    
                    context.opacity = alpha * 0.5
                    context.addFilter(.blur(radius: 2))
                    context.fill(
                        Path(ellipseIn: CGRect(x: position.x, y: position.y, width: 4, height: 4)),
                        with: .color(AppColors.richGold)
                    )
                }
            }
            .onChange(of: timeline.date) { oldValue, newValue in
                time += 0.016
            }
        }
    }
    
    private func particlePosition(index: Int, time: Double, size: CGSize) -> CGPoint {
        let angle = (Double(index) / Double(count)) * 2 * .pi
        let radius = 220.0 + sin(time * 2 + Double(index)) * 30 // Increased radius for particles
        let x = size.width/2 + cos(angle + time) * radius
        let y = size.height/2 + sin(angle + time) * radius
        return CGPoint(x: x, y: y)
    }
}

struct RotatingSphereView: View {
    @State private var rotation: Double = 0
    @State private var isLoading = true
    @State private var isLogosVisible = false
    @Binding var isComplete: Bool
    
    let timer = Timer.publish(every: 0.016, on: .main, in: .common).autoconnect()
    
    var body: some View {
        ZStack {
            // Background
            AppColors.maroonGradient.ignoresSafeArea()
            
            // Particle Effects
            ParticleSystem(count: 40) // More particles
                .opacity(0.6)
            
            // Glow Effects
            Circle()
                .fill(AppColors.richGold)
                .blur(radius: 70) // Increased blur radius
                .opacity(0.3)
            
            // Centered rotating logos - made even bigger
            GeometryReader { geometry in
                // Making the sphere much larger by using almost all available space
                let size = min(geometry.size.width, geometry.size.height) * 0.9 // Increased to 90% of available space
                
                ZStack {
                    // ASA Logo (Front)
                    Image("awz_logo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: size, height: size) // Much larger size
                        .clipShape(Circle())
                        .overlay(
                            Circle()
                                .stroke(AppColors.richGold, lineWidth: 4) // Thicker border
                                .blur(radius: 1.5)
                        )
                        .rotation3DEffect(
                            .degrees(rotation),
                            axis: (x: 0, y: 1, z: 0),
                            perspective: 0.3
                        )
                        .opacity(cos(Angle(degrees: rotation).radians) >= 0 ? 1 : 0)
                        .opacity(isLogosVisible ? 1 : 0)
                    
                    // Awaazein Logo (Back)
                    Image("asa_logo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: size, height: size) // Much larger size
                        .clipShape(Circle())
                        .overlay(
                            Circle()
                                .stroke(AppColors.richGold, lineWidth: 4) // Thicker border
                                .blur(radius: 1.5)
                        )
                        .rotation3DEffect(
                            .degrees(rotation - 180),
                            axis: (x: 0, y: 1, z: 0),
                            perspective: 0.3
                        )
                        .opacity(cos(Angle(degrees: rotation).radians) < 0 ? 1 : 0)
                        .opacity(isLogosVisible ? 1 : 0)
                }
                .frame(width: size, height: size)
                .position(x: geometry.size.width / 2, y: geometry.size.height / 2) // Center in the screen
                .shadow(color: AppColors.richGold.opacity(0.6), radius: 30) // Increased shadow
            }
        }
        .onAppear {
            // Show the logos immediately (no text)
            withAnimation(.easeInOut(duration: 1.0)) {
                isLogosVisible = true
            }
        }
        .onReceive(timer) { _ in
            if isLoading && isLogosVisible {
                withAnimation(.linear(duration: 0.016)) {
                    rotation += 1.5 // Rotation speed
                    
                    // Complete the loading screen after one full rotation
                    if rotation >= 360 {
                        isLoading = false
                        isComplete = true
                    }
                }
            }
        }
    }
}

struct LoadingScreenView: View {
    @State private var isLoadingComplete = false
    
    var body: some View {
        Group {
            if isLoadingComplete {
                MainTabView()
            } else {
                RotatingSphereView(isComplete: $isLoadingComplete)
            }
        }
    }
}

struct LoadingScreenView_Previews: PreviewProvider {
    static var previews: some View {
        LoadingScreenView()
    }
}
