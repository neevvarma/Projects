import SwiftUI

// Member struct to hold individual information
struct Member: Identifiable {
    let id = UUID()
    let name: String
    let bio: String
}

// Updated Committee struct
struct Committee: Identifiable {
    let id = UUID()
    let name: String
    let groupPhoto: String
    let members: [Member]
}

// First half of committees data
let committees = [
    Committee(
        name: "Directors",
        groupPhoto: "directors",
        members: [
            Member(
                name: "Vennela Jilla",
                bio: "A senior majoring in Animation and Video Game Design, she's as creative as it gets—from organizing epic photoshoots to bringing her imagination to life in stunning ways 📸💡. Vennela also holds down the fort as ICA President 👑. She's got a soft spot for Sexxy Red and The Weeknd 🎶 and an even softer spot for sleeping (she's pulled off 18-hour naps 😴!). One flaw? She's always running on 'Vennela Standard Time' 🕰️😅. Let's give her a huge welcome to the team! 🎉"
            ),
            Member(
                name: "Rhea Joshi",
                bio: "This Data Science senior has some seriously *flippin'* cool talents—like, literally. She can land a double backflip 🤸‍♀️, no sweat! She's also a total travel queen, having visited ALL 50 states 🗺️✈️. Her laugh? Impossible to resist, we dare you to try not to crack up 😂. With James Arthur vibes playing in the background 🎶, we know Rhea is going to bring some serious energy to the team. Let's welcome her with open arms (and maybe a flip or two)!"
            )
        ]
    ),
    Committee(
        name: "Assistant Directors",
        groupPhoto: "asst_directors",
        members: [
            Member(
                name: "Arya Biju",
                bio: "A Masters student in Information Technology & Management, Arya has a unique hobby of crushing the NYT Mini Crossword puzzles like a pro 🧩✨. Her eyeliner game? 20 seconds flat, no joke! 🖤👁️‍🗨️ She's a fan of Weston Estate 🎶 and serves on the ITM Student Leadership Council. Fun fact: she has an intense fear of the ocean, butterflies, and birds 🦋🌊. Arya is all set to graduate this semester and is looking forward to finishing strong! 🎓💫"
            ),
            Member(
                name: "Neev Varma",
                bio: "A senior majoring in Computer Science, he's currently honing his beatboxing skills 🎤🤩. A huge fan of Arijit Singh, Drake, and Lil Tecca 🎶, Neev is also an F1 fanatic 🏎️💨! When he's not working with the Information Security Department at UTD, you can find him geeking out about the latest race. One small flaw? He's a little indecisive… but we'll let it slide! 😄"
            )
        ]
    ),
    Committee(
        name: "Advisor",
        groupPhoto: "advisor",
        members: [
            Member(
                name: "Shreya Ramashesha",
                bio: "With her double major in Information Technology and Marketing, she's now working full-time as an analyst at Fidelity Investments 💼. Shreya is a certified chai connoisseur (seriously, her chai game is on point 🔥), a world traveler, and a cat foster mom 🐾. She's been classically trained in Carnatic music since age 4 🎶 and has a passion for photography 📸. Oh, and she's an avid reader and gym enthusiast 🏋️‍♀️! Fun fact: her comfort movie is Crazy Rich Asians 🌸. Welcome to the team, Shreya! 💼📚"
            )
        ]
    ),
    Committee(
        name: "Tech Advisor",
        groupPhoto: "tech",
        members: [
            Member(
                name: "Devanshi Verma",
                bio: "As a Biology major with a Music minor, she's not only passionate about science but also about hitting those high notes with Dhunki Acapella 🎤. She's got a serious talent for dancing 💃 and can hold a handstand for an impressive 5 minutes 🤸‍♀️! Her favorite artist? Ariana Grande, of course! 🎶 Fun fact: Devanshi is part of FeelGood and is always up for helping others. Oh, and she's a total foodie! 🍕🍩"
            )
        ]
    ),
    Committee(
        name: "Logistics",
        groupPhoto: "log",
        members: [
            Member(
                name: "Hima Patel",
                bio: "As a Healthcare Studies pre-med student, she's busy balancing studies, eating (her favorite hobby 🍔), and jamming to Drake. 🎶🦉 Fun fact: she's allergic to grass 🌱 but still shines on the dance floor with DTX Dandiya! 💃🔥 Watch out though—Hima's always ready for a good chat, she's a self-proclaimed yapper! 🗣️😄 Welcome to the team, Hima!"
            ),
            Member(
                name: "Vignesh Bhaskar",
                bio: "With 14 years of piano-playing under his belt, this senior Biology major is not only a music maestro but also the music director of NOVIS A Cappella 🎤. Fun fact: Vignesh has traveled to 20 countries 🌍✈️, so he's well-versed in both melodies and miles! When he's not tutoring at the SSC, you can catch him playing tennis or soccer 🎾⚽. Oh, and just a heads up—he might take a while to choose between those activities because he's very indecisive 😂. Welcome, Vignesh! 🎉"
            ),
            Member(
                name: "Varsha Janumpally",
                bio: "She's a powerhouse, balancing her passion for singing with Dhunki A Cappella 🎤 and her business studies in CIST/ITS. When she's not jamming out to The Weeknd or Lana Del Rey, she's making sure everything runs smoothly (even if she's a little indecisive). Fun fact: Varsha's energy is as bright as her favorite color, and we're excited to have her in the crew! 🎤✨ Welcome aboard, Varsha!"
            )
        ]
    ),
    Committee(
        name: "Finance",
        groupPhoto: "fin",
        members: [
            Member(
                name: "Suraj Sidda",
                bio: "A Finance major with a passion for all things sports, Suraj isn't just crunching numbers—he's out on the court, field, and even the squash court! Whether it's basketball, soccer, volleyball, or squash, Suraj is always up for a challenge. 🎯He's also the founder of an engineering fraternity here on campus (because why not add another leadership title, right?) and a proud member of Theta Tau Alpha. With Frank Ocean's \"Pyramids\" on repeat and a love for The Weeknd, Suraj knows how to balance business with balling! 🏀🎶"
            ),
            Member(
                name: "Sumedhasri Annabathini",
                bio: "Balancing spreadsheets and hoops, this ITS major knows how to bring her basketball game both on and off the court! Her favorite artist? Sabrina Carpenter 🎶Fun fact: She's got a loyal sidekick—her golden retriever Hobbes, named after the iconic duo Calvin and Hobbes. 🐾 Just don't offer her milk; she's lactose-intolerant but still unstoppable! 💪"
            ),
            Member(
                name: "Svetlana Gundabathula",
                bio: "A Biomedical Engineering major with a background of 15 years in dance, Svetlana's got moves both on and off the books! Whether she's busting a move or chilling with friends and family, she keeps it balanced. 📚💃Her go-to jam is \"Golden Hour\" by JVKE, but she's a true The Weeknd fan at heart. While her baking adventures are, as she says, \"mid,\" her ambition is anything but. Catch her balancing work at Aerie, volunteering, and juggling campus orgs like BMES and WMWE! 🍰💼"
            )
        ]
    )
]
// Additional committees data
extension Array where Element == Committee {
    static func additionalCommittees() -> [Committee] {
        return [
            Committee(
                name: "Sponsorship",
                groupPhoto: "spon",
                members: [
                    Member(
                        name: "Sumanasri Godavarti",
                        bio: "This Information Technology Systems major doesn't just excel in tech—she's also got an eye for detail, especially when it comes to caricaturing people! 🎭 On top of that, she's an amateur equestrian 🏇 and a Nerf gun sharpshooter with impeccable aim 🔫.When she's not jamming to Bruno Mars, you can find her active in Circle K, the Accounting Club, and Improv Club. Just don't count on her timing—it's legendary in the worst way! ⏰😅Welcome, Sumanasri! 🌟"
                    ),
                    Member(
                        name: "Dhvani Sharma",
                        bio: "A Healthcare Studies major and self-proclaimed certified shopaholic, Dhvani's got a talent for finding the perfect vibe, whether it's in her wardrobe or her music playlists. 🎶💃 She's always jamming to Bruno Mars, Lady Gaga, and Don Toliver, with a side of dancing in her free time! Beyond shopping and tunes, she's involved with Laksh 5.0 and the Pre-Dental Association. Just don't be surprised if she's zoning out mid-convo—it's her superpower! 🤯"
                    ),
                    Member(
                        name: "Niharika Saravana",
                        bio: "This Healthcare Studies major has some serious skills—when she's not knitting or crocheting away her stress, you can find her hitting the bullseye after 10 years of archery 🏹!Her playlist? A mix of Diljit Dosanjh, Anirudh, Chris Brown, and Bruno Mars 🎶. She's also busy making moves at the hospital and with AMWA. But whatever you do... don't eat with your mouth open around her! 🙅‍♀️😅Welcome, Niharika! 🎉"
                    )
                ]
            ),
            Committee(
                name: "Liason Coordinators",
                groupPhoto: "lc",
                members: [
                    Member(
                        name: "Sneha Maram",
                        bio: "This Computer Science sophomore has a creative side—whether it's knitting, crafting, or busting a move on stage! 💻🧶 Oh, and did we mention? She's danced in Bali 🌺🏝️ and is a professional Kuchipudi dancer—talk about global talent! 💃✨Sneha's fave artist lineup includes Cuco and Kendrick, and she's jamming out to \"Now or Never\" these days. 🎶 As for her fun fact? Well... she might \"forget\" to text you back 🫣 but trust us, it's all love! ❤️Welcome Sneha to the team! 🎉"
                    ),
                    Member(
                        name: "Rishul Aggarwal",
                        bio: "This Healthcare Management and Leadership master's student is our resident eating champ who proudly embraces his \"foodie\" title. 🍕😄 His favorite artist? 4batz, and fun fact—he was their #1 listener! 🎧🔥When he's not jamming out or advising for ICA, you can find him looking for the perfect job (seriously, someone help him out! 🙏). We're hyped to have him bring all the energy to LC!"
                    ),
                    Member(
                        name: "Rithika Shenoy",
                        bio: "This ITS junior, fast-tracking into an MS in ITM, is all about balance—literally! She's got the flexibility to pull off some cool tricks and the smarts to ace her studies. 🤸‍♀️💻 With 13 piercings (and counting 🤩), her vibe is as unique as her music taste—currently vibing with Jhene Aiko and Summer Walker. 🎧Rithika's fun fact? She's a memory collector who has to snap a pic or write it down to remember (pics or it didn't happen, right? 😎📸). A lover of reading, dancing, and singing (10 years strong!), she's always down to meet new people and share some great book recs. 📚💃We're so lucky to have her!"
                    )
                ]
            ),
            Committee(
                name: "AfterParty",
                groupPhoto: "ap",
                members: [
                    Member(
                        name: "Khushi Patel",
                        bio: "This Global Business and HR junior is a master of dancing, cooking, and baking—basically a triple threat! 🔥 She loves all kinds of music (just not rock 🎶) and has a serious passion for food. 🍕🍜When she's not choreographing her next dance routine or practicing Taekwondo, she's busy with GBO and whipping up something delicious in the kitchen. Oh, and she's ready to throw the After Party of the year! 🎉Her flaw? Just a little bit of overthinking! 😅"
                    ),
                    Member(
                        name: "Shriya Thippana",
                        bio: "This Information Technology and Systems senior can bust out the Cotton-Eyed Joe at a moment's notice, and she's always ready for a hike! 🕺🏞️ Her go-to jam? \"Unwritten\" by Natasha Bedingfield! 🎶✨When she's not hitting the trails, Shriya serves as the outreach coordinator for Camp Kesem, bringing her passion to everything she does. Just don't trust her with the aux and directions at the same time! 😅We're so excited to have Shriya on board! 💫"
                    ),
                    Member(
                        name: "Venuka Srivastava",
                        bio: "This Healthcare Studies senior is a master of crocheting, knitting, and sewing—basically a crafting queen who jokingly calls herself a grandma! 😄🎀 But don't be fooled, she's also a total gym rat who can't resist a sweet treat at the end of the day. 🍩💪Venuka's music taste is as cool as her hobbies—think The Backseat Lovers, Still Woozy, and Tyler the Creator. 🎶 And did we mention? She's got a metal rod in her left wrist from a skateboarding incident two years ago! 🛹We're thrilled to have her bring the best vibes to the After Party! 🎉"
                    )
                ]
            ),
            Committee(
                name: "Marketing",
                groupPhoto: "mark",
                members: [
                    Member(
                        name: "Aari Madireddy",
                        bio: "This Supply Chain Management senior isn't just a marketing whiz—she's also got a flair for fashion and loves making her own clothes! ✂️👚 And when she's not busy with us, you'll find her dressing up and hanging out with friends. 💃👯‍♀️Her soundtrack for life? Taylor Swift, of course! 🎶 And here's a fun tidbit: Aari's love for naps is legendary. 💤😴Welcome, Aari! We're excited to see your creative touch in action!"
                    ),
                    Member(
                        name: "Omisha Cherala",
                        bio: "This Computer Science junior has a passion for all things DIY—whether it's painting, crafting, or embroidery, she's always making something unique! 🎨✨ Her current jam? \"Die For You (Remix)\" by The Weeknd ft. Ariana Grande 🎶Fun fact: Omisha has over 15 playlists, each carefully curated by vibes and genres. 🎧 She's also the Hospitality Chair for Hansini, showing her leadership skills both on and off campus. Her one struggle? Being very indecisive and maybe a little too gullible. 😅 But hey, we think it just makes her more lovable! Welcome, Omisha! 💖"
                    ),
                    Member(
                        name: "Saniya Hameed",
                        bio: "This double major in Neuroscience and Psychology is an absolute powerhouse when it comes to marketing! When she's not busy making waves with us, you can find her singing, playing piano, traveling, or diving deep into a good book. 🎹🌍📖Her go-to playlist? A mix of Gracie Abrams, Taylor Swift, Sabrina Carpenter, and Noah Kahan on repeat for days 🎶 And here's something cool—Saniya is double-jointed in her fingers and toes! 🤯She's also the performance coordinator for Dallas Musical Outreach, spreading her love for music everywhere. 🎤🎶 Her one flaw? Sometimes she's so into a book that she'll sneak a read during hangouts. 🤭📱Welcome, Saniya! We're so excited to have you! 💫"
                    )
                ]
            ),
            Committee(
                name: "Graphics",
                groupPhoto: "graph",
                members: [
                    Member(
                        name: "Pranav Cherala",
                        bio: "Meet Pranav, our senior Graphics guru! ✨💻 A Healthcare Studies major with a flair for design, Pranav also collects coins as a hobby! 💰He loves Bryson Tiller and Partynextdoor 🎶 and has danced at both UTD Laksh and UTD Raftaar! 🕺💃 Off-campus, he volunteers at blood donation centers and hospitals. 🩸🏥 His quirky trait? He's a bit forgetful, but that's just part of his charm! 😉 Welcome, Pranav! We're thrilled to have you!"
                    ),
                    Member(
                        name: "Aarushi Mohanty",
                        bio: "Meet Aarushi, our global citizen! ✨🌍 A junior Psychology major, Aarushi has traveled and studied worldwide, including Switzerland! 🇨🇭 When she's not analyzing floor plans for fun, she's vibing to Tate McRae, Taylor Swift, Travis Scott, or Chase Atlantic. 🎶💫 Fluent in English, Hindi, Odia, German, and French, Aarushi is also an Epilepsy Foundation ambassador and a behavioral therapist for kids with autism. 💜 Her one flaw? Being a bit indecisive, but we're sure she'll figure it out! Welcome to the squad, Aarushi!"
                    ),

                    Member(
                        name: "Syam Konala",
                        bio: "Meet Syam, our talented junior! 💻🏀 A Biomedical Engineering major, Syam excels on and off the field. When he's not designing, he's playing basketball, soccer, or lifting weights! 🏋️‍♂️⚽️ His current jam is \"Sorrows\" by Bryson Tiller 🎶 and he's tough—he's had stitches on the same spot on his head three times! 💥🙈 Syam's also with Theta Tau Alpha, though he's still tackling procrastination. 😅 Welcome to the crew, Syam!"
                    )
                ]
            ),
            Committee(
                name: "Hospitality",
                groupPhoto: "hosp",
                members: [
                    Member(
                        name: "Shivani Kumar",
                        bio: "This Computer Science sophomore is not only diving into the world of tech but also exploring the art of crochet—she started learning this summer! 🧵✨ Her current musical obsession? Lana Del Rey 🎶💫When she's not working on her crochet skills, you can find her experimenting with chaotic recipes, like making pasta from scratch! 🍝🔬 She's also a Road Warriors mentor and part of the choir, balancing multiple passions with ease. 🚀🎤Shivani might be a bit quiet at first, but once you get to know her, she's a gem! 💎 Welcome to the team, Shivani!"
                    ),
                    Member(
                        name: "Pallavi Tumuluru",
                        bio: "A sophomore majoring in Biomedical Engineering, Pallavi brings both brains and talent to the team. She's been singing for over a decade and even posts song covers on her Instagram! 🎶🎙️Her current fave? Don Toliver on repeat! 🎧 When she's not belting out tunes, you might catch her laughing at the worst possible moments—even in serious situations! 😂We're thrilled to have Pallavi bringing her creativity and energy to the team!💫"
                    ),
                    Member(
                        name: "Kakoli Bhardwaj",
                        bio: "A Business Analytics major, Kakoli brings her creative flair to the team with a love for art—especially painting! 🎨✨ When she's not busy with the Business Analytics Leadership Council or mentoring freshmen, she's hanging out with her adorable Pomeranian. 🐕💕 Her favorite song? \"To the Stars\" by the PropheC 🎶 And as a true foodie, she believes there's no such thing as too much good food! 🍕🍣 Plus, she's a globetrotter at heart—on a mission to visit every continent someday! 🌍✈️ We're so excited to have Kakoli on board! 💫"
                    )
                ]
            ),
            Committee(
                name: "Mixer",
                groupPhoto: "mixer",
                members: [
                    Member(
                        name: "Sivani Yalamanchili",
                        bio: "This Information Technology & Systems senior is an animal lover with a twist—she has a soft spot for reptiles and brings them home whenever she finds one! 🦎✨ When Sivani's not out finding her next scaly friend, you can catch her reading or swimming. Music-wise, she's all about Kanye West's beats! 🎶🔥 On top of that, she's active in DKD and WITB, managing it all despite being a bit indecisive at times (we think it adds to her charm)! 😄We can't wait to see her shake things up this year! 💫"
                    ),
                    Member(
                        name: "Maria Williams",
                        bio: "This Neuroscience senior has a special talent—she always manages to misplace her phone! 😅 When she's not on the lookout for it, you'll find her vibing to \"Self Love\" by Metro Boomin and Coi Leray 🎶✨Fun fact: Maria is a passionate dancer, and when she's not busting a move, she's busy as a Peer Advisor. Oh, and she's the proud owner of a Doberman! 🐕💕Her one kryptonite? Cleaning her room! 🧹 But we love her anyway! 💫"
                    ),
                    Member(
                        name: "Khushi Aggarwal",
                        bio: "This ITS sophomore has a serious addiction to running side quests (in games and in life!) and is always leveling up. 🎮✨ Her go-to jam? \"Scared of My Guitar\" by Olivia Rodrigo! 🎶💫When she's not gaming, Khushi's busy baking up her own recipes or belting out tunes. 🍪🎤 Plus, she's an active member of Laksh and the Indian Cultural Association! Oh, and if things get awkward, expect her to start laughing—it's her signature move! 😆We're so excited to have Khushi on the team, bringing all the creativity and energy! 💫"
                    )
                ]
            )
        ]
    }
}

// Update the committees array
// All the view code for displaying committees and bios
struct BoardMembersView: View {
    // Combine all committees
    let allCommittees = committees + Array.additionalCommittees()
    
    var body: some View {
        NavigationView {
            ZStack {
                // Base background with gradient
                LinearGradient(gradient: Gradient(colors: [AppColors.deepMaroon, Color.black]),
                             startPoint: .top,
                             endPoint: .bottom)
                    .ignoresSafeArea()
                
                ScrollView(.vertical, showsIndicators: false) {
                    VStack(spacing: 20) {
                        // Title Section
                        Text("Your Awaazein Board")
                            .font(.custom("Palatino-Bold", size: 36))
                            .foregroundColor(AppColors.richGold)
                            .shadow(color: AppColors.richGold.opacity(0.5), radius: 10)
                            .padding(.top, 20)
                            .padding(.bottom, 15)
                        
                        // Board Members Grid
                        LazyVGrid(columns: [GridItem(.flexible())], spacing: 25) {
                            ForEach(allCommittees) { committee in
                                CommitteeCard(committee: committee)
                            }
                        }
                        .padding(.horizontal, 15)
                        .padding(.bottom, 20)
                    }
                }
            }
            .navigationBarHidden(true)
        }
    }
}

struct CommitteeCard: View {
    let committee: Committee
    @State private var showingBio = false
    
    var body: some View {
        ZStack {
            // Card Background
            LinearGradient(
                gradient: Gradient(colors: [
                    AppColors.deepMaroon.opacity(0.7),
                    AppColors.nightBlack.opacity(0.9)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .cornerRadius(25)
            .shadow(color: AppColors.richGold.opacity(0.2), radius: 10)
            
            VStack(spacing: 0) {
                // Committee Image
                if let image = UIImage(named: committee.groupPhoto) {
                    Image(uiImage: image)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: 200)
                        .background(AppColors.charcoal.opacity(0.3))
                } else {
                    Rectangle()
                        .fill(AppColors.charcoal)
                        .frame(height: 200)
                        .overlay(
                            Image(systemName: "photo.fill")
                                .font(.system(size: 40))
                                .foregroundColor(AppColors.richGold)
                        )
                }
                
                // Committee Information
                VStack(alignment: .leading, spacing: 10) {
                    Text(committee.name)
                        .font(.system(size: 24, weight: .bold, design: .rounded))
                        .foregroundColor(AppColors.richGold)
                    
                    ForEach(committee.members) { member in
                        Text(member.name)
                            .font(.system(size: 16))
                            .foregroundColor(.white)
                    }
                }
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(AppColors.charcoal.opacity(0.5))
            }
            .cornerRadius(25)
            .overlay(
                RoundedRectangle(cornerRadius: 25)
                    .stroke(AppColors.richGold.opacity(0.3), lineWidth: 1)
            )
            .onTapGesture {
                showingBio = true
            }
        }
        .sheet(isPresented: $showingBio) {
            BioDetailView(committee: committee)
        }
    }
}

struct BioDetailView: View {
    let committee: Committee
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ZStack {
            // Background
            AppColors.maroonGradient
                .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 25) {
                    // Committee Photo
                    if let image = UIImage(named: committee.groupPhoto) {
                        Image(uiImage: image)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: 250)
                            .clipShape(RoundedRectangle(cornerRadius: 25))
                            .overlay(
                                RoundedRectangle(cornerRadius: 25)
                                    .stroke(AppColors.richGold, lineWidth: 2)
                            )
                            .shadow(color: AppColors.richGold.opacity(0.4), radius: 15)
                    }
                    
                    // Committee Name
                    Text(committee.name)
                        .font(.system(size: 32, weight: .bold, design: .rounded))
                        .foregroundColor(AppColors.richGold)
                    
                    // Member Bios
                    ForEach(committee.members) { member in
                        MemberBioCard(member: member)
                    }
                }
                .padding()
            }
            
            // Close Button
            VStack {
                HStack {
                    Spacer()
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 30))
                            .foregroundColor(AppColors.richGold)
                            .padding()
                    }
                }
                Spacer()
            }
        }
    }
}

struct MemberBioCard: View {
    let member: Member
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(member.name)
                .font(.system(size: 24, weight: .bold))
                .foregroundColor(AppColors.softGold)
            
            Text(member.bio)
                .font(.system(size: 16))
                .foregroundColor(.white)
                .lineSpacing(4)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color.black.opacity(0.3))
        .cornerRadius(15)
        .overlay(
            RoundedRectangle(cornerRadius: 15)
                .stroke(AppColors.richGold.opacity(0.3), lineWidth: 1)
        )
    }
}

struct BoardMembersView_Previews: PreviewProvider {
    static var previews: some View {
        BoardMembersView()
    }
}
