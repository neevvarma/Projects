import SwiftUI
import WebKit
import Firebase
import FirebaseDatabase

struct LivestreamView: View {
    @State private var videoURL: URL?
    @State private var youtubeVideoID: String = ""
    @State private var showAdminView = false
    @State private var isAdminAuthenticated = false
    @State private var isCurtainOpen = false
    @State private var errorMessage: String?
    @StateObject private var livestreamState = LivestreamState.shared
    
    // Firebase Reference
    private var ref: DatabaseReference? = Database.database().reference()
    
    var body: some View {
        ZStack {
            // Background
            AppColors.maroonGradient
                .ignoresSafeArea()
            
            // Main Content
            ScrollView {
                VStack(spacing: 0) {
                    // Theater Ceiling
                    TheaterCeiling()
                    
                    // Content Area
                    ZStack {
                        // Theater Wall
                        TheaterWall()
                        
                        // Main Content Stack
                        VStack(spacing: 30) {
                            // Title
                            Text("Awaazein Live")
                                .font(.system(size: 48, weight: .bold, design: .rounded))
                                .foregroundColor(AppColors.richGold)
                                .shadow(color: AppColors.richGold.opacity(0.5), radius: 10)
                                .padding(.top, 40)
                                .onLongPress(minimumDuration: 3) {
                                    showAdminView = true
                                }
                            
                            // Livestream Screen
                            ZStack {
                                // Screen Frame
                                RoundedRectangle(cornerRadius: 20)
                                    .fill(Color.black)
                                    .shadow(color: AppColors.richGold.opacity(0.3), radius: 15)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 20)
                                            .stroke(AppColors.richGold, lineWidth: 2)
                                    )
                                
                                // Content Selection
                                if livestreamState.isPreviewMode {
                                    // Preview Mode Content
                                    VStack(spacing: 20) {
                                        Text("Awaazein 2024 Recap")
                                            .font(.system(size: 32, weight: .bold))
                                            .foregroundColor(AppColors.richGold)
                                        
                                        Text("Relive the Memories!")
                                            .font(.system(size: 24, weight: .semibold))
                                            .foregroundColor(AppColors.softGold)
                                        
                                        if let videoURL = videoURL {
                                            VideoPlayerWithFullScreen(url: videoURL)
                                        } else {
                                            Text("Video Not Available")
                                                .foregroundColor(AppColors.softGold)
                                        }
                                    }
                                    .padding()
                                } else {
                                    // Livestream Content
                                    LivestreamContentView(
                                        youtubeVideoID: $youtubeVideoID,
                                        errorMessage: $errorMessage
                                    )
                                }
                                
                                // Curtains
                                HStack(spacing: 0) {
                                    TheaterCurtain(side: .left, isOpen: isCurtainOpen)
                                    TheaterCurtain(side: .right, isOpen: isCurtainOpen)
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 300)
                            .padding()
                            
                            // Theater Seats
                            TheaterSeats()
                        }
                    }
                    
                    // Additional content outside the theater
                    VStack(spacing: 40) {
                        // 2024 Video Section
                        VStack(alignment: .leading, spacing: 15) {
                            Text("Check Out Awaazein 2024")
                                .font(.system(size: 28, weight: .bold))
                                .foregroundColor(AppColors.richGold)
                                .padding(.horizontal)
                            
                            // Fixed 2024 video embed
                            YouTubeEmbedView(videoID: "0JiGj-miwdc")
                                .frame(height: 200)
                                .cornerRadius(15)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 15)
                                        .stroke(AppColors.richGold, lineWidth: 2)
                                )
                                .padding(.horizontal)
                        }
                        .padding(.vertical)
                        .background(
                            RoundedRectangle(cornerRadius: 20)
                                .fill(Color.black.opacity(0.3))
                        )
                        .padding(.horizontal)
                        .padding(.top, 30)
                        
                        // YouTube Channel Link
                        VStack(spacing: 15) {
                            Text("Find More Competition Clips Here")
                                .font(.system(size: 22, weight: .bold))
                                .foregroundColor(AppColors.richGold)
                                .padding(.horizontal)
                            
                            Link(destination: URL(string: "https://www.youtube.com/@awaazeinexecutiveboard6223")!) {
                                Image("youtube_logo") // Ensure this asset exists in Assets.xcassets
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 50)
                                    .padding(.vertical, 10)
                                    .padding(.horizontal, 30)
                                    .background(
                                        RoundedRectangle(cornerRadius: 15)
                                            .fill(Color.black.opacity(0.5))
                                            .overlay(
                                                RoundedRectangle(cornerRadius: 15)
                                                    .stroke(AppColors.richGold, lineWidth: 2)
                                            )
                                    )
                            }
                            .padding(.bottom, 10)
                        }
                        .padding(.vertical)
                        .background(
                            RoundedRectangle(cornerRadius: 20)
                                .fill(Color.black.opacity(0.3))
                        )
                        .padding(.horizontal)
                        .padding(.bottom, 30)
                    }
                }
            }
        }
        .onAppear {
            loadLocalVideo()
            setupLivestreamObserver()
            withAnimation(.easeInOut(duration: 2.0)) {
                isCurtainOpen = true
            }
        }
        .onDisappear {
            isCurtainOpen = false
            removeObservers()
        }
        .sheet(isPresented: $showAdminView) {
            if !isAdminAuthenticated {
                AdminAuthView(isAuthenticated: $isAdminAuthenticated)
            } else {
                AdminLivestreamView(isAuthenticated: $isAdminAuthenticated)
            }
        }
    }
    
    private func loadLocalVideo() {
        if let path = Bundle.main.path(forResource: "awaazein_2024", ofType: "mp4") {
            videoURL = URL(fileURLWithPath: path)
        }
    }
    
    // Setup a real-time observer for livestream URL changes
    private func setupLivestreamObserver() {
        // Reset any existing error message
        self.errorMessage = nil
        
        // Setup a permanent observer for the currentVideoID in Firebase
        ref?.child("livestream").child("currentVideoID").observe(.value) { snapshot in
            if let videoID = snapshot.value as? String {
                print("✅ Livestream Updated - Video ID: \(videoID)")
                
                // Check if videoID is "neev" - if so, show the coming soon message
                if videoID.lowercased() == "neev" {
                    print("🚫 Special case 'neev' detected - showing coming soon message")
                    self.youtubeVideoID = ""
                    self.errorMessage = "Livestream will be available soon"
                } else {
                    self.youtubeVideoID = videoID
                    self.errorMessage = nil
                }
            } else {
                print("❌ No Video ID Found")
                self.errorMessage = "No livestream available"
            }
        } withCancel: { error in
            print("❌ Firebase Observer Error: \(error.localizedDescription)")
            self.errorMessage = "Error connecting to livestream service"
        }
    }
    
    // Remove observers when view disappears to prevent memory leaks
    private func removeObservers() {
        ref?.child("livestream").child("currentVideoID").removeAllObservers()
    }
    
    // Helper method to extract YouTube video ID (unchanged)
    private func extractYouTubeVideoID(from link: String) -> String? {
        // Remove any whitespace
        let cleanedLink = link.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // Verbose logging
        print("🔍 Attempting to extract video ID from: \(cleanedLink)")
        
        // Comprehensive regex patterns
        let patterns = [
            // Explicit match for watch URL with v parameter
            "v=([^&\\s]+)",
            
            // Standard watch URL with or without https
            "(?:https?:\\/\\/)?(?:www\\.)?youtube\\.com\\/watch\\?.*v=([^&\\s]+)",
            
            // Shortened youtu.be links
            "youtu\\.be\\/([^?&\\s]+)",
            
            // Embed links
            "(?:https?:\\/\\/)?(?:www\\.)?youtube\\.com\\/embed\\/([^?&\\s]+)"
        ]
        
        for pattern in patterns {
            do {
                let regex = try NSRegularExpression(pattern: pattern, options: [])
                if let match = regex.firstMatch(in: cleanedLink, options: [], range: NSRange(location: 0, length: cleanedLink.utf16.count)) {
                    
                    let nsString = cleanedLink as NSString
                    let videoIDRange = match.range(at: 1)
                    
                    if videoIDRange.location != NSNotFound {
                        let extractedID = nsString.substring(with: videoIDRange)
                        print("✅ Extracted Video ID: \(extractedID)")
                        return extractedID
                    }
                }
            } catch {
                print("❌ Regex Error: \(error)")
            }
        }
        
        // Fallback manual parsing
        if let urlComponents = URLComponents(string: cleanedLink),
           let queryItems = urlComponents.queryItems,
           let videoID = queryItems.first(where: { $0.name == "v" })?.value {
            print("✅ Extracted Video ID (URLComponents): \(videoID)")
            return videoID
        }
        
        print("❌ Failed to extract Video ID")
        return nil
    }
}

// Separate View for Livestream Content
struct LivestreamContentView: View {
    @Binding var youtubeVideoID: String
    @Binding var errorMessage: String?
    
    var body: some View {
        VStack {
            if let errorMessage = errorMessage {
                // Error Handling View with "Coming Soon" message
                VStack(spacing: 15) {
                    Text("Live Stream Coming Soon")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundColor(AppColors.richGold)
                    
                    Image(systemName: "video.fill")
                        .font(.system(size: 40))
                        .foregroundColor(AppColors.softGold)
                        .padding(.vertical, 10)
                    
                    Text(errorMessage)
                        .font(.system(size: 16))
                        .foregroundColor(AppColors.softGold)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 20)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if !youtubeVideoID.isEmpty {
                // YouTube Embedded Player
                YouTubeEmbedView(videoID: youtubeVideoID)
            } else {
                // Loading State
                LoadingView()
            }
        }
    }
}

// Custom YouTube Embed View
struct YouTubeEmbedView: UIViewRepresentable {
    let videoID: String
    
    func makeUIView(context: Context) -> WKWebView {
        // Proper configuration is key
        let webConfiguration = WKWebViewConfiguration()
        webConfiguration.allowsInlineMediaPlayback = true
        webConfiguration.mediaTypesRequiringUserActionForPlayback = []
        
        let webView = WKWebView(frame: .zero, configuration: webConfiguration)
        webView.scrollView.isScrollEnabled = false
        return webView
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {
        // Use HTML embedding for better playback control
        let html = """
        <!DOCTYPE html>
        <html>
        <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body, html { margin: 0; padding: 0; width: 100%; height: 100%; }
                iframe { width: 100%; height: 100%; border: none; }
            </style>
        </head>
        <body>
            <iframe src="https://www.youtube.com/embed/\(videoID)?playsinline=1&controls=1" 
                    frameborder="0" 
                    allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" 
                    allowfullscreen>
            </iframe>
        </body>
        </html>
        """
        
        uiView.loadHTMLString(html, baseURL: URL(string: "https://www.youtube.com"))
        
        // For debugging
        print("Loading YouTube video ID: \(videoID)")
    }
}
