import SwiftUI
import AVKit

struct ContentView: View {
    // Target date: March 8th, 2025 at 5:30 PM
    let targetDate: Date = {
        var calendar = Calendar.current
        calendar.timeZone = TimeZone.current
        
        var components = DateComponents()
        components.year = 2025
        components.month = 3
        components.day = 8
        components.hour = 17
        components.minute = 30
        components.second = 0
        components.timeZone = TimeZone.current
        
        return calendar.date(from: components) ?? Date()
    }()
    
    @State private var daysRemaining: Int = 0
    @State private var hoursRemaining: Int = 0
    @State private var minutesRemaining: Int = 0
    @State private var secondsRemaining: Int = 0
    
    @State private var currentEvent: String = "Countdown to Awaazein"
    @State private var eventIndex: Int = 0
    @State private var isCountdownActive: Bool = true
    @State private var eventEndDate: Date = Date()
    @State private var isEventComplete: Bool = false
    @State private var showingVideoPlayer = false
    
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    let teams: [[TeamData]] = [
        [
            TeamData(name: "UW Awaaz", imageAsset: "UW_Awaaz_logo"),
            TeamData(name: "UMD Anokha", imageAsset: "UMD_Anokha_logo")
        ],
        [
            TeamData(name: "UT Hum", imageAsset: "UT_Hum_logo"),
            TeamData(name: "UCD Jhankaar", imageAsset: "UCD_Jhankaar_logo")
        ],
        [
            TeamData(name: "UCB Dil Se", imageAsset: "UCB_Dil_Se_logo"),
            TeamData(name: "UCLA Naya Zamaana", imageAsset: "UCLA_Naya_Zamaana_logo")
        ],
        [
            TeamData(name: "UH Dhun", imageAsset: "UH_Dhun_logo"),
            TeamData(name: "TAMU Swaram", imageAsset: "TAMU_Swaram_logo")
        ],
        [
            TeamData(name: "SLU Astha", imageAsset: "SLU_Astha_logo"),
            TeamData(name: "OSU Dhadkan", imageAsset: "OSU_Dhadkan_logo")
        ]
    ]
    
    var body: some View {
        ZStack {
            // Layered background
            AppColors.maroonGradient
                .ignoresSafeArea()
            
            // Animated background patterns
            GeometryReader { geometry in
                ZStack {
                    // Circles pattern
                    ForEach(0..<3) { index in
                        Circle()
                            .fill(AppColors.richGold.opacity(0.1))
                            .frame(width: geometry.size.width * 0.8)
                            .blur(radius: 50)
                            .offset(x: geometry.size.width * 0.2 * CGFloat(index),
                                    y: geometry.size.height * 0.1 * CGFloat(index))
                    }
                    
                    // Diamond pattern
                    ForEach(0..<5) { index in
                        Rectangle()
                            .fill(AppColors.richGold.opacity(0.05))
                            .frame(width: 100, height: 100)
                            .rotationEffect(.degrees(45))
                            .blur(radius: 20)
                            .offset(x: CGFloat(index) * 100 - 200,
                                    y: CGFloat(index) * 100 - 200)
                    }
                }
            }
            
            ScrollView {
                VStack(spacing: 30) {
                    // Title Section
                    Text("AWAAZEIN")
                        .font(.system(size: 48, weight: .bold, design: .rounded))
                        .foregroundColor(AppColors.richGold)
                        .padding(.top, 40)
                    
                    // Countdown Section
                    VStack(spacing: 20) {
                        Text(isEventComplete ? "Event Complete" : currentEvent)
                            .font(.system(size: 24, weight: .semibold))
                            .foregroundColor(AppColors.softGold)
                        
                        if !isEventComplete {
                            HStack(spacing: 15) {
                                TimeCard(value: daysRemaining, unit: "DAYS")
                                TimeCard(value: hoursRemaining, unit: "HOURS")
                                TimeCard(value: minutesRemaining, unit: "MINS")
                                TimeCard(value: secondsRemaining, unit: "SECS")
                            }
                            .padding(.horizontal)
                        }
                    }
                    .padding()
                    .glassCard()
                    .padding(.horizontal)
                    
                    // Ticket Purchase Section
                    VStack(spacing: 15) {
                        Text("Purchase Your Tickets")
                            .font(.system(size: 32, weight: .bold))
                            .foregroundColor(AppColors.richGold)
                        
                        Text("Join us for an unforgettable night of South Asian a cappella!")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                        
                        Link(destination: URL(string: "https://docs.google.com/forms/d/e/1FAIpQLScEcoALnBK2lwWsu3zrDgW6wndiWBRSwXyctGtLKlWrFbwD-A/viewform?usp=header")!) {
                            HStack {
                                Image(systemName: "ticket.fill")
                                Text("Get Tickets")
                            }
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundColor(.black)
                            .padding(.horizontal, 30)
                            .padding(.vertical, 15)
                            .background(AppColors.richGold)
                            .cornerRadius(25)
                        }
                    }
                    .padding()
                    .glassCard()
                    .padding(.horizontal)
                    
                    // Venue Section
                    VStack(spacing: 15) {
                        Text("Coppell Arts Center")
                            .font(.system(size: 32, weight: .bold))
                            .foregroundColor(AppColors.richGold)
                        
                        Text("505 Travis St, Coppell, TX 75019")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                        
                        // Venue Image - replace "coppell_arts_center" with your actual image asset name
                        Image("coppell_arts_center") // Use placeholder if this asset doesn't exist
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(height: 200)
                            .cornerRadius(15)
                            .clipped()
                            .overlay(
                                RoundedRectangle(cornerRadius: 15)
                                    .stroke(AppColors.richGold, lineWidth: 2)
                            )
                            .padding(.horizontal)
                            .padding(.top, 5)
                        
                        // Link to maps
                        Link(destination: URL(string: "https://maps.apple.com/?address=505%20Travis%20St,%20Coppell,%20TX%2075019")!) {
                            HStack {
                                Image(systemName: "map.fill")
                                Text("Directions")
                            }
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundColor(.black)
                            .padding(.horizontal, 25)
                            .padding(.vertical, 12)
                            .background(AppColors.richGold)
                            .cornerRadius(20)
                        }
                        .padding(.top, 10)
                    }
                    .padding()
                    .glassCard()
                    .padding(.horizontal)
                    
                    // Teams Section
                    VStack(spacing: 25) {
                        Text("Meet the Teams")
                            .font(.system(size: 32, weight: .bold))
                            .foregroundColor(AppColors.richGold)
                        
                        VStack(spacing: 30) {
                            ForEach(teams, id: \.self) { row in
                                HStack(spacing: 40) {
                                    ForEach(row, id: \.name) { team in
                                        TeamCard(team: team)
                                    }
                                }
                            }
                        }
                        .padding(.horizontal)
                    }
                    .padding()
                    .premiumCard()
                    .padding(.horizontal)
                    
                    // NEW: Line Up Video Section
                    VStack(spacing: 15) {
                        Text("Check Out our Line Up Video!")
                            .font(.system(size: 32, weight: .bold))
                            .foregroundColor(AppColors.richGold)
                            .multilineTextAlignment(.center)
                        
                        Button(action: {
                            showingVideoPlayer = true
                        }) {
                            HStack {
                                Image(systemName: "play.fill")
                                Text("Watch Now")
                            }
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundColor(.black)
                            .padding(.horizontal, 30)
                            .padding(.vertical, 15)
                            .background(AppColors.richGold)
                            .cornerRadius(25)
                        }
                        .shadow(color: AppColors.richGold.opacity(0.4), radius: 10)
                    }
                    .padding()
                    .glassCard()
                    .padding(.horizontal)
                    
                    // NEW: Social Media Section
                    VStack(spacing: 15) {
                        Text("Follow Us on our Socials")
                            .font(.system(size: 32, weight: .bold))
                            .foregroundColor(AppColors.richGold)
                            .multilineTextAlignment(.center)
                        
                        HStack(spacing: 30) {
                            // Instagram Button
                            Link(destination: URL(string: "https://www.instagram.com/awaazein/")!) {
                                VStack(spacing: 5) {
                                    Image("instagram_logo") // Add this asset to your project
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: 60, height: 60)
                                        .clipShape(RoundedRectangle(cornerRadius: 15))
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 15)
                                                .stroke(AppColors.richGold, lineWidth: 2)
                                        )
                                    
                                    Text("Instagram")
                                        .font(.system(size: 14, weight: .medium))
                                        .foregroundColor(AppColors.softGold)
                                }
                            }
                            
                            // TikTok Button
                            Link(destination: URL(string: "https://www.tiktok.com/@awaazein25?lang=en")!) {
                                VStack(spacing: 5) {
                                    Image("tiktok_logo") // Add this asset to your project
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: 60, height: 60)
                                        .clipShape(RoundedRectangle(cornerRadius: 15))
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 15)
                                                .stroke(AppColors.richGold, lineWidth: 2)
                                        )
                                    
                                    Text("TikTok")
                                        .font(.system(size: 14, weight: .medium))
                                        .foregroundColor(AppColors.softGold)
                                }
                            }
                        }
                        .padding(.vertical, 10)
                    }
                    .padding()
                    .glassCard()
                    .padding(.horizontal)
                    .padding(.bottom, 20)
                }
                .padding(.bottom, 50)
            }
        }
        .sheet(isPresented: $showingVideoPlayer) {
            LineUpVideoPlayer(videoName: "awaazein_intro")
        }
        .onReceive(timer) { _ in
            if isEventComplete {
                return
            }
            if isCountdownActive {
                updateTimeRemaining()
            } else {
                updateEventTimer()
            }
        }
        .onAppear {
            updateTimeRemaining()
        }
    }
    
    func updateTimeRemaining() {
        let now = Date()
        
        guard targetDate > now else {
            isCountdownActive = false
            startEventSchedule()
            return
        }
        
        let calendar = Calendar.current
        let components = calendar.dateComponents([.day, .hour, .minute, .second], from: now, to: targetDate)

        daysRemaining = components.day ?? 0
        hoursRemaining = components.hour ?? 0
        minutesRemaining = components.minute ?? 0
        secondsRemaining = components.second ?? 0

        if daysRemaining <= 0 && hoursRemaining <= 0 && minutesRemaining <= 0 && secondsRemaining <= 0 {
            isCountdownActive = false
            startEventSchedule()
        }
    }

    func startEventSchedule() {
        currentEvent = "Pre-Show"
        eventEndDate = Calendar.current.date(byAdding: .minute, value: 18, to: Date())!

        DispatchQueue.main.asyncAfter(deadline: .now() + (18 * 60)) {
            startTeamSchedule()
        }
    }

    func startTeamSchedule() {
        let teamNames = ["Team 1", "Team 2", "Team 3", "Team 4", "Team 5", "Team 6", "Team 7", "Team 8", "Team 9", "Team 10"]

        for (index, team) in teamNames.enumerated() {
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(index * (13 * 60))) {
                if index == teamNames.count - 1 {
                    currentEvent = "Now Performing: \(team)"
                    eventEndDate = Calendar.current.date(byAdding: .minute, value: 13, to: Date())!
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + (13 * 60)) {
                        isEventComplete = true
                        currentEvent = "Event Complete"
                    }
                } else {
                    currentEvent = "Now Performing: \(team)"
                    eventEndDate = Calendar.current.date(byAdding: .minute, value: 13, to: Date())!
                }
            }
        }
    }

    func updateEventTimer() {
        if isEventComplete {
            return
        }
        
        let now = Date()
        let difference = Calendar.current.dateComponents([.day, .hour, .minute, .second], from: now, to: eventEndDate)

        daysRemaining = difference.day ?? 0
        hoursRemaining = difference.hour ?? 0
        minutesRemaining = difference.minute ?? 0
        secondsRemaining = difference.second ?? 0

        if daysRemaining <= 0 && hoursRemaining <= 0 && minutesRemaining <= 0 && secondsRemaining <= 0 {
            eventEndDate = Calendar.current.date(byAdding: .minute, value: 13, to: Date())!
        }
    }
    
    func membersForTeam(_ teamName: String) -> [String] {
        switch teamName {
        case "UW Awaaz":
            return [
                "Advaith Bulusu", "Neethi Belur", "Akshata Aravind",
                "Sathya Venkatesan", "Sanjana Somayajula", "Yug Purohit",
                "Niranjanaa Kannan", "Arnav Khare", "Nicole Chang",
                "Pramati Barath", "Archit Ganapule", "Maya Bhat",
                "Udith Sreejith", "Sai Pappuru", "Sruthi Alamuru"
            ]
        case "UMD Anokha":
            return [
                "Saanika Mahashetty", "Rishika Jadhav", "Gavin Willard",
                "Anuraag Tripathy", "Sheena Agrawal", "Rachel Rodrigues",
                "Jay Nadkarni", "Elizabeth Ipe", "Nikhil Mudunuri",
                "Shriya Rejeesh", "Alex Joseph", "Abha Phillips",
                "Arshia Mondal", "Varun Kannepalli"
            ]
        case "TAMU Swaram":
            return [
                "Smaran Karthik", "Aaron Jacob", "Bea Binu",
                "Govind Joshi", "Varsha Kumar", "Pranav Venkatraman",
                "Abhinav Sheshadri", "Sanjana Seenuvasan", "Sanah Alex",
                "Sri Sanjana Pithani", "Rohan Ganta", "Ritvik Balachandar",
                "Esha Thote", "Nishant Udupa"
            ]
        case "OSU Dhadkan":
            return [
                "Neha Bellamkonda", "Avi Jain", "Savir Krishnan", "Ahan Parikh",
                "Vidya Rajagopal", "Animesh Rajagopalan", "Sahana Rajesh",
                "Vibha Ramesh", "Rakshu Sankarraman", "Yadnya Sonawane",
                "Sanju Nandimalla", "Harini Senthil", "Sadhana Sivakumar",
                "Sravya Tanneer", "Meghana Boda", "Ruchira Patil",
                "Devakh Rashie", "Manay Chokshi"
            ]
        case "SLU Astha":
            return [
                "Madhura Puntambekar", "Karun Puri", "Anika Karumuri",
                "Diyadatt Seeryada", "Amirtha Vijay", "Niveditha Jose",
                "Aditi Srinivasan", "Prajoy Jayanth", "Aahil Abdul Nazeer",
                "Meghana Gangireddy", "Santosh Hanumanthiah", "George Panagapolous",
                "Aaron Shiju", "Srija Boddu"
            ]
        case "UT Hum":
            return [
                "Pavitra Sreedhar", "Tanushree Duggirala", "Sindhu Vasudevan",
                "Sanjana Sen", "Shreya Sunkari", "Sanjana Ganesh", "Ananya Kannan",
                "Dinah Thadikonda", "Rakshith Mallesh", "Saujash Barman",
                "Kaushal Chamarthy", "Arjun Singhal", "Vikas Dhulipala",
                "Udbhav Narani", "Arnav Chopra", "Aakash Makwana"
            ]
        case "UCB Dil Se":
            return [
                "Vennila Annamalai", "Saketh Korrapolu", "Teja Nivarthi",
                "Aneesh Bhat", "Rishi Reddy", "Saumya Soni", "Manya Sriram",
                "Dhruv Gore", "Rishipriyo Aich", "Ritika Joshi", "Prisha Mangat",
                "Abhinav Goel", "Preethi Kumar", "Aswin Surya",
                "Amrutha Srivatsav", "Sohini Torvi"
            ]
        case "UCD Jhankaar":
            return [
                "Varsha Harnoor", "Risitha Bellignur", "Malini Iyer",
                "Aditi Anand", "Tara Sung", "Grace Nedungadan", "Vincent Casas",
                "Adi Chatterjee", "Priya Ramamurthy", "Rhea Manjunath"
            ]
        case "UH Dhun":
            return [
                "Dhriti Raju", "Nagasrinidhi Kuruvada", "Debayush Banerjee",
                "Heera Shetty", "Reya Patel", "Arpitha Ramesh", "Prithvi Muratee",
                "Mahima Nagaraj", "Bani Bhatia", "Rishi Vadaga"
            ]
        case "UCLA Naya Zamaana":
            return [
                "Sai Anish Kuppili", "Tanisha Pulla", "Paurush Pandey",
                "Puja Anand", "Vilas Iyer", "Srija Bhowmik", "Alishah Mohammed",
                "Ira Kulkarni", "Shravani Venkatesh", "Ajeeth Iyer", "Jiya Singh",
                "Rishi Padmanabhan", "Sharabh Ohja"
            ]
        default:
            return []
        }
    }
}

// Line Up Video Player
struct LineUpVideoPlayer: View {
    let videoName: String
    @State private var player: AVPlayer?
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.black.edgesIgnoringSafeArea(.all)
                
                if let player = player {
                    VideoPlayer(player: player)
                        .edgesIgnoringSafeArea(.all)
                        .onAppear {
                            player.play()
                        }
                        .onDisappear {
                            player.pause()
                        }
                } else {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: AppColors.richGold))
                        .scaleEffect(2)
                }
            }
            .navigationBarTitle("Line Up Video", displayMode: .inline)
            .navigationBarItems(trailing: Button(action: {
                presentationMode.wrappedValue.dismiss()
            }) {
                Image(systemName: "xmark.circle.fill")
                    .foregroundColor(AppColors.richGold)
                    .font(.system(size: 22))
            })
        }
        .onAppear {
            setupPlayer()
        }
    }
    
    private func setupPlayer() {
        guard let url = Bundle.main.url(forResource: videoName, withExtension: "mp4") else {
            print("Could not find video: \(videoName).mp4")
            return
        }
        
        player = AVPlayer(url: url)
    }
}

struct TeamCard: View {
    let team: TeamData
    @State private var isHovered = false
    
    var body: some View {
        NavigationLink(destination: TeamDetailView(
            teamName: team.name,
            logoName: team.imageAsset,
            teamPhotoName: "\(team.name)_team", // Adjust this if your naming convention is different
            members: ContentView().membersForTeam(team.name)
        )) {
            VStack {
                Image(team.imageAsset)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 80, height: 80)
                    .clipShape(Circle())
                    .overlay(
                        Circle()
                            .stroke(AppColors.richGold, lineWidth: 2)
                    )
                    .shadow(color: AppColors.richGold.opacity(0.5), radius: isHovered ? 10 : 5)
                
                Text(team.name)
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(AppColors.softGold)
                    .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .padding()
            .glassCard()
            .scaleEffect(isHovered ? 1.05 : 1)
            .animation(.spring(response: 0.3), value: isHovered)
        }
    }
}

struct TeamData: Hashable {
    let name: String
    let imageAsset: String
}

struct TimeCard: View {
    let value: Int
    let unit: String
    @State private var isAnimating = false
    
    var body: some View {
        VStack(spacing: 8) {
            Text("\(value)")
                .font(.system(size: 32, weight: .bold))
                .foregroundColor(AppColors.richGold)
            
            Text(unit)
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(AppColors.softGold)
        }
        .frame(width: 70, height: 90)
        .background(
            RoundedRectangle(cornerRadius: 15)
                .fill(Color.black.opacity(0.3))
                .overlay(
                    RoundedRectangle(cornerRadius: 15)
                        .stroke(AppColors.richGold.opacity(0.5), lineWidth: 1)
                )
        )
        .scaleEffect(isAnimating ? 1 : 0.9)
        .onAppear {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
                isAnimating = true
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

