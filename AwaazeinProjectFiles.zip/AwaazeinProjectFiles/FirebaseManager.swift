import Foundation
import FirebaseCore
import FirebaseDatabase

class FirebaseManager {
    static let shared = FirebaseManager()
    private var ref: DatabaseReference?
    
    private init() {
        ref = Database.database().reference()
    }
    
    func fetchCurrentVideoID(completion: @escaping (String?) -> Void) {
        ref?.child("livestream").child("currentVideoID").observeSingleEvent(of: .value) { snapshot in
            if let videoID = snapshot.value as? String {
                print("📺 Found Video ID: \(videoID)")
                completion(videoID)
            } else {
                print("❌ No video ID found")
                completion(nil)
            }
        }
    }
}

