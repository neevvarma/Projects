import SwiftUI

struct AdminAuthView: View {
    @State private var password = ""
    @State private var showError = false
    @Binding var isAuthenticated: Bool
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ZStack {
            // Background gradient
            AppColors.maroonGradient
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                // Header with dismiss button
                HStack {
                    Spacer()
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        Image(systemName: "xmark")
                            .foregroundColor(AppColors.richGold)
                            .padding()
                            .background(Color.black.opacity(0.2))
                            .clipShape(Circle())
                    }
                }
                .padding(.top)
                .padding(.horizontal)
                
                // Title
                Text("Admin Access")
                    .font(.largeTitle)
                    .foregroundColor(AppColors.richGold)
                
                // Password Field
                SecureField("Enter Admin Password", text: $password)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                    .background(Color.white.opacity(0.1))
                    .cornerRadius(10)
                    .foregroundColor(.white)
                
                // Login Button
                Button(action: authenticate) {
                    Text("Login")
                        .foregroundColor(.white)
                        .padding()
                        .background(AppColors.richGold)
                        .cornerRadius(10)
                }
                
                // Error Message
                if showError {
                    Text("Invalid Credentials")
                        .foregroundColor(.red)
                }
                
                Spacer()
            }
            .padding()
        }
    }
    
    private func authenticate() {
        if SecureStorageManager.shared.validateAdminCredentials(password: password) {
            isAuthenticated = true
        } else {
            showError = true
            password = ""
        }
    }
}
