import SwiftUI

struct TeamDetailView: View {
    let teamName: String
    let logoName: String
    let teamPhotoName: String
    let members: [String]
    
    var body: some View {
        ZStack {
            // Background gradient
            AppColors.maroonGradient
                .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 25) {
                    // Team Name with modern styling
                    Text(teamName)
                        .font(.system(size: 40, weight: .bold, design: .rounded))
                        .foregroundColor(AppColors.richGold)
                        .shadow(color: AppColors.richGold.opacity(0.3), radius: 10)
                        .padding(.top, 40)
                    
                    // Team Logo
                    Image(logoName)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: 100)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(AppColors.richGold, lineWidth: 2))
                        .shadow(color: AppColors.richGold.opacity(0.4), radius: 10)
                    
                    // Team Photo with enhanced presentation
                    Image(teamPhotoName.replacingOccurrences(of: " ", with: "_"))
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: 300)
                        .clipShape(RoundedRectangle(cornerRadius: 25))
                        .overlay(
                            RoundedRectangle(cornerRadius: 25)
                                .stroke(AppColors.richGold, lineWidth: 3)
                        )
                        .shadow(color: AppColors.richGold.opacity(0.4), radius: 15)
                    
                    // Members Section with modern card design
                    VStack(alignment: .leading, spacing: 15) {
                        Text("Team Members")
                            .font(.system(size: 28, weight: .semibold))
                            .foregroundColor(AppColors.richGold)
                        
                        LazyVGrid(columns: [
                            GridItem(.flexible()),
                            GridItem(.flexible())
                        ], spacing: 10) {
                            ForEach(members.sorted(), id: \.self) { member in
                                HStack {
                                    Text("•")
                                        .foregroundColor(AppColors.richGold)
                                    Text(member)
                                        .foregroundColor(.white)
                                        .font(.system(size: 14))
                                }
                            }
                        }
                    }
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 25)
                            .fill(Color.black.opacity(0.3))
                            .overlay(
                                RoundedRectangle(cornerRadius: 25)
                                    .stroke(AppColors.richGold.opacity(0.5), lineWidth: 2)
                            )
                    )
                    .padding()
                }
            }
        }
        .navigationBarTitle("", displayMode: .inline)
        .onAppear {
            print("TeamDetailView appeared for \(teamName)")
            print("logoName: \(logoName)")
            print("teamPhotoName: \(teamPhotoName)")
            print("Adjusted teamPhotoName: \(teamPhotoName.replacingOccurrences(of: " ", with: "_"))")
        }
    }
}

struct TeamDetailView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            TeamDetailView(
                teamName: "UW Awaaz",
                logoName: "UW_Awaaz_logo",
                teamPhotoName: "UW Awaaz_team",
                members: [
                    "Advaith Bulusu", "Neethi Belur", "Akshata Aravind",
                    "Sathya Venkatesan", "Sanjana Somayajula", "Yug Purohit",
                    "Niranjanaa Kannan", "Arnav Khare", "Nicole Chang",
                    "Pramati Barath", "Archit Ganapule", "Maya Bhat",
                    "Udith Sreejith", "Sai Pappuru", "Sruthi Alamuru"
                ]
            )
        }
    }
}
